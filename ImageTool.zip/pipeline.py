"""
Embroidery Preprocessing Pipeline
==================================
Converts LLM-generated cartoon-like portraits into embroidery-friendly images
suitable for auto-digitizing tools (e.g., Wilcom).

Design principle:
  - Outlines = structure (dark strokes, preserved exactly as black)
  - Whites = highlights (teeth, eye whites, preserved as pure white)
  - Colors = fill (quantized, cleaned, flattened)
  - Background removal via flood-fill edge detection

Dependencies: OpenCV (cv2), NumPy
"""

import os
import cv2
import numpy as np

# ---------------------------------------------------------------------------
# Default configuration
# ---------------------------------------------------------------------------
DEFAULT_CONFIG = {
    "width": 768,               # legacy key — mapped to working_width internally
    "working_width": 768,       # internal processing resolution (portrait-friendly)
    "output_width": 1200,       # final export width for Wilcom (background_only_mode)
    "K": 12,                    # portrait default — enough colors for skin, hair, clothing
    "bilateral_d": 5,           # moderate smoothing for clean skin tones
    "bilateral_sigma_color": 40,
    "bilateral_sigma_space": 40,
    "morph_kernel_size": 3,
    "dark_threshold": 70,       # tighter — avoids picking up facial shadows as outlines
    "white_threshold": 200,
    "remove_bg": True,
    "bg_alpha_cutoff": 128,
    "enable_smoothing": True,
    "enable_quantization": True,
    "enable_cleanup": True,
    "enable_outlines": True,
    "enable_whites": True,
    "background_only_mode": True,   # recommended default for portrait workflow
    "upscale_background_only": True, # upscale bg-only output to output_width
    "portrait_safe_mode": True,      # gentler full-stylization for portraits
    "enable_face_enhancement": True, # region-aware face feature enhancement
    "enable_clothing_smoothing": True, # texture simplification on clothing region
    "enable_hair_refinement": True,    # mild cleanup on hair region
    "debug": False,
    "debug_dir": "debug_output",
    "bg_lab_tolerance": 25,     # conservative — safer around hair and clothing edges
}

_RNG_SEED = 42


# ---------------------------------------------------------------------------
# Stage 1 – Resize
# ---------------------------------------------------------------------------
def resize_image(image: np.ndarray, width: int = 512) -> np.ndarray:
    h, w = image.shape[:2]
    scale = width / w
    return cv2.resize(image, (width, int(h * scale)), interpolation=cv2.INTER_AREA)


# ---------------------------------------------------------------------------
# Stage 2 – Extract outline mask
# ---------------------------------------------------------------------------
def extract_outline_mask(image: np.ndarray, dark_threshold: int = 80) -> np.ndarray:
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    return (gray < dark_threshold).astype(np.uint8) * 255


# ---------------------------------------------------------------------------
# Stage 3 – Extract white highlight mask (teeth, eye whites)
# ---------------------------------------------------------------------------
def extract_white_mask(image: np.ndarray, white_threshold: int = 200) -> np.ndarray:
    b, g, r = cv2.split(image)

    # Use threshold to control sensitivity
    min_val = max(white_threshold - 30, 100)
    bright = (
        (r > min_val) &
        (g > min_val - 10) &
        (b > min_val - 20)
    ).astype(np.uint8) * 255

    # remove very large regions so background / clothing don't get picked
    h, w = image.shape[:2]
    max_area = int(0.01 * h * w)

    num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(bright, connectivity=8)
    result = np.zeros((h, w), dtype=np.uint8)

    for lbl in range(1, num_labels):
        area = stats[lbl, cv2.CC_STAT_AREA]
        if area <= max_area:
            result[labels == lbl] = 255

    return result

def extract_light_region_mask(image: np.ndarray) -> np.ndarray:
    b, g, r = cv2.split(image)

    # detect very light regions like white clothing
    light_mask = (
        (r > 200) &
        (g > 200) &
        (b > 200)
    ).astype(np.uint8) * 255

    # smooth small gaps/noise
    kernel = np.ones((5, 5), np.uint8)
    light_mask = cv2.morphologyEx(light_mask, cv2.MORPH_CLOSE, kernel)
    light_mask = cv2.morphologyEx(light_mask, cv2.MORPH_OPEN, kernel)

    # keep only large components
    h, w = image.shape[:2]
    min_area = int(0.02 * h * w)

    num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(
        light_mask, connectivity=8
    )

    result = np.zeros((h, w), dtype=np.uint8)
    for lbl in range(1, num_labels):
        if stats[lbl, cv2.CC_STAT_AREA] >= min_area:
            result[labels == lbl] = 255

    return result

# ---------------------------------------------------------------------------
# Stage 4 – Build color layer
# ---------------------------------------------------------------------------
def build_color_layer(image: np.ndarray, protected_mask: np.ndarray) -> np.ndarray:
    return cv2.inpaint(image, protected_mask, inpaintRadius=5, flags=cv2.INPAINT_TELEA)


# ---------------------------------------------------------------------------
# Stage 5 – Bilateral filter
# ---------------------------------------------------------------------------
def apply_bilateral_filter(image: np.ndarray, d: int = 5,
                           sigma_color: int = 40, sigma_space: int = 40) -> np.ndarray:
    return cv2.bilateralFilter(image, d, sigma_color, sigma_space)


# ---------------------------------------------------------------------------
# Stage 6 – K-means color quantization
# ---------------------------------------------------------------------------
def kmeans_quantization(image: np.ndarray, K: int = 5,
                        fg_mask: np.ndarray | None = None) -> np.ndarray:
    """Quantize foreground in CIELAB space. Background pixels are left unchanged."""
    h, w, c = image.shape
    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
    all_pixels = lab.reshape(-1, 3).astype(np.float32)

    if fg_mask is not None:
        fg_flat = fg_mask.flatten() > 0
        cluster_pixels = all_pixels[fg_flat]
    else:
        fg_flat = None
        cluster_pixels = all_pixels

    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 20, 1.0)
    cv2.setRNGSeed(_RNG_SEED)
    _, labels, centers = cv2.kmeans(cluster_pixels, K, None, criteria, 10,
                                     cv2.KMEANS_PP_CENTERS)

    if fg_flat is not None:
        # Only recolor foreground pixels; background keeps original RGB
        result = image.copy()
        fg_indices = np.where(fg_flat)[0]
        quantized_fg = np.uint8(centers)[labels.flatten()]
        # Convert quantized LAB back to BGR
        fg_bgr = cv2.cvtColor(quantized_fg.reshape(1, -1, 3), cv2.COLOR_LAB2BGR).reshape(-1, 3)
        result_flat = result.reshape(-1, 3)
        result_flat[fg_indices] = fg_bgr
        return result_flat.reshape(h, w, 3)
    else:
        all_labels = labels.flatten()
        quantized_lab = np.uint8(centers)[all_labels].reshape(h, w, 3)
        return cv2.cvtColor(quantized_lab, cv2.COLOR_LAB2BGR)


# ---------------------------------------------------------------------------
# Stage 7 – Remove small noisy regions
# ---------------------------------------------------------------------------
def remove_small_regions(image: np.ndarray, min_area: int = 500,
                        fg_mask: np.ndarray | None = None) -> np.ndarray:
    """Replace tiny color blobs with their dominant neighbor.
    If fg_mask is provided, only process regions fully inside foreground."""
    h, w, c = image.shape
    flat = image.reshape(-1, c)
    color_ids = (flat[:, 0].astype(np.int32) * 65536 +
                 flat[:, 1].astype(np.int32) * 256 +
                 flat[:, 2].astype(np.int32))
    color_id_map = color_ids.reshape(h, w)
    result = image.copy()

    fg_binary = None
    if fg_mask is not None:
        fg_binary = fg_mask > 0

    for uid in np.unique(color_id_map):
        mask = np.uint8(color_id_map == uid) * 255
        num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
        for lbl in range(1, num_labels):
            if stats[lbl, cv2.CC_STAT_AREA] >= min_area:
                continue
            comp_mask = labels == lbl
            # Skip regions that touch background boundary
            if fg_binary is not None and not np.all(fg_binary[comp_mask]):
                continue
            dilated = cv2.dilate(comp_mask.astype(np.uint8) * 255,
                                 np.ones((5, 5), np.uint8), iterations=2)
            neighbor_mask = (dilated > 0) & ~comp_mask
            if not np.any(neighbor_mask):
                continue
            nc = result[neighbor_mask]
            nc_enc = (nc[:, 0].astype(np.int64) * 65536 +
                      nc[:, 1].astype(np.int64) * 256 +
                      nc[:, 2].astype(np.int64))
            values, counts = np.unique(nc_enc, return_counts=True)
            d = values[np.argmax(counts)]
            result[comp_mask] = np.array(
                [(d >> 16) & 0xFF, (d >> 8) & 0xFF, d & 0xFF], dtype=np.uint8
            )
    return result


# ---------------------------------------------------------------------------
# Stage 8 – Morphological closing
# ---------------------------------------------------------------------------
def apply_morphology(image: np.ndarray, kernel_size: int = 3) -> np.ndarray:
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (kernel_size, kernel_size))
    return cv2.morphologyEx(image, cv2.MORPH_CLOSE, kernel)


# ---------------------------------------------------------------------------
# Stage 9 – Merge near-duplicate colors
# ---------------------------------------------------------------------------
def merge_similar_colors(image: np.ndarray, min_distance: int = 12) -> np.ndarray:
    """Merge perceptually similar colors using LAB Delta-E distance,
    consistent with the LAB-space K-means quantization."""
    unique_bgr = np.unique(image.reshape(-1, 3), axis=0)
    if len(unique_bgr) <= 1:
        return image

    # Convert to LAB for perceptual comparison
    unique_bgr_3d = unique_bgr.reshape(1, -1, 3).astype(np.uint8)
    unique_lab = cv2.cvtColor(unique_bgr_3d, cv2.COLOR_BGR2LAB).reshape(-1, 3).astype(np.float32)

    merge_to = {}
    used = set()
    for i in range(len(unique_lab)):
        k1 = tuple(unique_bgr[i].astype(int))
        if k1 in used:
            continue
        used.add(k1)
        for j in range(i + 1, len(unique_lab)):
            k2 = tuple(unique_bgr[j].astype(int))
            if k2 in used:
                continue
            if np.linalg.norm(unique_lab[i] - unique_lab[j]) < min_distance:
                merge_to[k2] = k1
                used.add(k2)

    if not merge_to:
        return image
    result = image.copy()
    for src, dst in merge_to.items():
        mask = np.all(result == np.array(src, dtype=np.uint8), axis=2)
        result[mask] = np.array(dst, dtype=np.uint8)
    return result

def normalize_outline(mask: np.ndarray, thickness: int = 2) -> np.ndarray:
    kernel = np.ones((thickness, thickness), np.uint8)
    return cv2.dilate(mask, kernel, iterations=1)

# ---------------------------------------------------------------------------
# Stage 11 – Composite layers
# ---------------------------------------------------------------------------
def composite_final(color_layer: np.ndarray, outline_mask: np.ndarray,
                    white_mask: np.ndarray, white_pixels: np.ndarray) -> np.ndarray:
    result = color_layer.copy()
    result[white_mask > 0] = white_pixels[white_mask > 0]
    result[outline_mask > 0] = [0, 0, 0]
    return result


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def save_output(image: np.ndarray, path: str) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    cv2.imwrite(path, image, [cv2.IMWRITE_PNG_COMPRESSION, 0])


def _debug_save(image: np.ndarray, debug_dir: str, name: str) -> None:
    os.makedirs(debug_dir, exist_ok=True)
    cv2.imwrite(os.path.join(debug_dir, f"{name}.png"), image,
                [cv2.IMWRITE_PNG_COMPRESSION, 0])

# DEPRECATED: replaced by border-based estimate_border_bg_color + LAB distance.
# Kept for backward compatibility but no longer called by the pipeline.
def build_magenta_candidate_mask(
    image: np.ndarray,
    bg_color=(255, 0, 255),
    lab_tolerance: int = 35
) -> np.ndarray:
    # LAB closeness
    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB).astype(np.int16)
    bg_patch = np.zeros((1, 1, 3), dtype=np.uint8)
    bg_patch[0, 0] = np.array(bg_color, dtype=np.uint8)
    bg_lab = cv2.cvtColor(bg_patch, cv2.COLOR_BGR2LAB).astype(np.int16)[0, 0]
    dist = np.sqrt(np.sum((lab - bg_lab) ** 2, axis=2)).astype(np.float32)
    lab_mask = dist <= lab_tolerance

    # HSV magenta-like rule
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    h = hsv[:, :, 0]
    s = hsv[:, :, 1]
    v = hsv[:, :, 2]

    hsv_mask = (
        (h >= 140) & (h <= 170) &
        (s >= 80) &
        (v >= 80)
    )

    candidate = (lab_mask | hsv_mask).astype(np.uint8) * 255

    kernel = np.ones((3, 3), np.uint8)
    candidate = cv2.morphologyEx(candidate, cv2.MORPH_OPEN, kernel)
    candidate = cv2.morphologyEx(candidate, cv2.MORPH_CLOSE, kernel)
    candidate = cv2.dilate(candidate, kernel, iterations=1)

    return candidate

def extract_background_alpha(image: np.ndarray, alpha_cutoff: int = 128) -> np.ndarray:
    """Remove background using flood-fill from edges.
    Protects subject by detecting skin-tone and dark (outline) regions."""
    return extract_background_alpha_from_original(image)


def fill_holes(mask: np.ndarray) -> np.ndarray:
    h, w = mask.shape[:2]
    inv = cv2.bitwise_not(mask)
    flood = inv.copy()
    ff_mask = np.zeros((h + 2, w + 2), np.uint8)
    cv2.floodFill(flood, ff_mask, (0, 0), 128)
    holes = (flood == 255).astype(np.uint8) * 255
    return cv2.bitwise_or(mask, holes)


def estimate_border_bg_color(image: np.ndarray, quant_step: int = 16) -> np.ndarray:
    h, w = image.shape[:2]

    border_pixels = np.vstack([
        image[0, :, :],
        image[h - 1, :, :],
        image[:, 0, :],
        image[:, w - 1, :]
    ]).astype(np.int32)

    # Quantize to reduce tiny variations
    q = (border_pixels // quant_step) * quant_step

    encoded = q[:, 0] * 256 * 256 + q[:, 1] * 256 + q[:, 2]
    values, counts = np.unique(encoded, return_counts=True)
    dominant = values[np.argmax(counts)]

    b = (dominant // (256 * 256)) & 255
    g = (dominant // 256) & 255
    r = dominant & 255

    return np.array([b, g, r], dtype=np.uint8)


def extract_background_alpha_from_original(
    image: np.ndarray,
    lab_tolerance: int = 32
) -> np.ndarray:
    h, w = image.shape[:2]
    kernel = np.ones((3, 3), np.uint8)

    # 1. Detect dominant background color from border
    bg_color = estimate_border_bg_color(image)

    # 2. LAB similarity mask
    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB).astype(np.int16)

    bg_patch = np.zeros((1, 1, 3), dtype=np.uint8)
    bg_patch[0, 0] = bg_color
    bg_lab = cv2.cvtColor(bg_patch, cv2.COLOR_BGR2LAB).astype(np.int16)[0, 0]

    dist = np.sqrt(np.sum((lab - bg_lab) ** 2, axis=2)).astype(np.float32)
    candidate = (dist <= lab_tolerance).astype(np.uint8) * 255

    # 3. Clean candidate mask
    candidate = cv2.morphologyEx(candidate, cv2.MORPH_OPEN, kernel)
    candidate = cv2.morphologyEx(candidate, cv2.MORPH_CLOSE, kernel)

    # 4. Keep only border-connected candidate as real background
    flood = candidate.copy()

    for x in range(w):
        if flood[0, x] == 255:
            ff_mask = np.zeros((h + 2, w + 2), np.uint8)
            cv2.floodFill(flood, ff_mask, (x, 0), 128)
        if flood[h - 1, x] == 255:
            ff_mask = np.zeros((h + 2, w + 2), np.uint8)
            cv2.floodFill(flood, ff_mask, (x, h - 1), 128)

    for y in range(h):
        if flood[y, 0] == 255:
            ff_mask = np.zeros((h + 2, w + 2), np.uint8)
            cv2.floodFill(flood, ff_mask, (0, y), 128)
        if flood[y, w - 1] == 255:
            ff_mask = np.zeros((h + 2, w + 2), np.uint8)
            cv2.floodFill(flood, ff_mask, (w - 1, y), 128)

    background_mask = (flood == 128).astype(np.uint8) * 255

    # 5. Invert to foreground
    fg_mask = cv2.bitwise_not(background_mask)

    # 6. Fill holes + cleanup
    fg_mask = fill_holes(fg_mask)
    fg_mask = cv2.morphologyEx(fg_mask, cv2.MORPH_CLOSE, kernel)
    fg_mask = cv2.medianBlur(fg_mask, 3)

    return fg_mask

# ---------------------------------------------------------------------------
# Path helpers
# ---------------------------------------------------------------------------
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_IMAGES_DIR = os.path.join(_SCRIPT_DIR, "images")
_GENERATED_DIR = os.path.join(_SCRIPT_DIR, "generated")


def _resolve_input_path(name: str) -> str:
    """Resolve an image name to its full path in the images/ folder."""
    # If it's already a full/relative path that exists, use it
    if os.path.isfile(name):
        return name

    # Try images/<name> directly
    candidate = os.path.join(_IMAGES_DIR, name)
    if os.path.isfile(candidate):
        return candidate

    # Try images/<name>.png, .jpg, .jpeg
    base, ext = os.path.splitext(name)
    if not ext:
        for ext in [".png", ".jpg", ".jpeg"]:
            candidate = os.path.join(_IMAGES_DIR, base + ext)
            if os.path.isfile(candidate):
                return candidate

    raise FileNotFoundError(
        f"Image not found: tried '{name}' and images/{name}[.png|.jpg|.jpeg]"
    )


def _default_output_path(input_path: str) -> str:
    """Generate output path: generated/<name>_embroidery.png"""
    base = os.path.splitext(os.path.basename(input_path))[0]
    os.makedirs(_GENERATED_DIR, exist_ok=True)
    return os.path.join(_GENERATED_DIR, f"{base}_embroidery.png")

def remove_color_spill(image: np.ndarray, alpha: np.ndarray, bg_color: np.ndarray) -> np.ndarray:
    """
    Remove background color spill from foreground boundary pixels.
    Works even when alpha is binary.
    """
    img = image.copy().astype(np.float32)

    # Binary foreground mask
    fg = (alpha > 127).astype(np.uint8) * 255

    # Build a narrow boundary ring around the foreground
    kernel = np.ones((3, 3), np.uint8)
    dilated = cv2.dilate(fg, kernel, iterations=1)
    eroded = cv2.erode(fg, kernel, iterations=1)
    edge_ring = ((dilated > 0) & (eroded == 0))

    # Compare edge pixels to actual background color
    bg = bg_color.astype(np.float32)
    diff = np.linalg.norm(img - bg, axis=2)

    # Spill pixels = boundary pixels still too close to bg color
    spill = edge_ring & (diff < 90)

    if not np.any(spill):
        return image

    # Replace spill pixels using nearby interior foreground color
    clean_source = cv2.medianBlur(image, 5).astype(np.float32)
    img[spill] = clean_source[spill]

    return img.astype(np.uint8)

# ---------------------------------------------------------------------------
# Main pipeline
# ---------------------------------------------------------------------------
def trim_foreground_alpha(alpha: np.ndarray, trim_px: int = 3) -> np.ndarray:
    """
    Remove thin contaminated edge rim from foreground mask.
    For embroidery-style output, a small inward trim is acceptable.
    """
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    trimmed = cv2.erode(alpha, kernel, iterations=trim_px)
    trimmed = cv2.morphologyEx(trimmed, cv2.MORPH_OPEN, kernel)
    return trimmed


def premultiply_rgb_with_alpha(image: np.ndarray, alpha: np.ndarray) -> np.ndarray:
    """
    Multiply RGB by alpha so transparent edge pixels don't keep visible pink RGB.
    """
    img = image.astype(np.float32)
    a = (alpha.astype(np.float32) / 255.0)[:, :, np.newaxis]
    out = img * a
    return np.clip(out, 0, 255).astype(np.uint8)


# ---------------------------------------------------------------------------
# Portrait region estimation (background_only_mode only)
# ---------------------------------------------------------------------------
def estimate_portrait_regions(image: np.ndarray, alpha: np.ndarray) -> dict:
    """Estimate face, hair, and clothing masks using geometric + color heuristics.
    Works only inside foreground (alpha > 127). No ML dependencies."""
    h, w = image.shape[:2]
    fg = (alpha > 127).astype(np.uint8)
    face_mask = np.zeros((h, w), dtype=np.uint8)
    hair_mask = np.zeros((h, w), dtype=np.uint8)
    clothing_mask = np.zeros((h, w), dtype=np.uint8)

    if not np.any(fg):
        return {"face_mask": face_mask, "hair_mask": hair_mask, "clothing_mask": clothing_mask}

    ys, xs = np.where(fg > 0)
    y_min, y_max = ys.min(), ys.max()
    x_min, x_max = xs.min(), xs.max()
    fg_h = y_max - y_min + 1
    fg_w = x_max - x_min + 1

    # --- Geometric face zone: upper ~45% height, central ~60% width ---
    face_y_top = y_min
    face_y_bot = y_min + int(fg_h * 0.45)
    face_x_left = x_min + int(fg_w * 0.20)
    face_x_right = x_min + int(fg_w * 0.80)

    # --- Skin color refinement inside geometric zone ---
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)

    # Skin heuristic: HSV hue 0-25, saturation 30-170, value 80-255
    skin = (
        (hsv[:, :, 0] <= 25) &
        (hsv[:, :, 1] >= 30) & (hsv[:, :, 1] <= 170) &
        (hsv[:, :, 2] >= 80)
    ).astype(np.uint8)

    # Build geometric zone mask
    geo_zone = np.zeros((h, w), dtype=np.uint8)
    geo_zone[face_y_top:face_y_bot, face_x_left:face_x_right] = 1

    # Face = skin-like pixels inside geometric zone AND foreground
    face_raw = (skin & geo_zone & fg).astype(np.uint8) * 255

    # Clean up with morphology — fill small gaps (eyebrows, lips)
    k_close = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))
    face_raw = cv2.morphologyEx(face_raw, cv2.MORPH_CLOSE, k_close)
    face_raw = cv2.morphologyEx(face_raw, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))

    # Keep only the largest connected component as the face
    n_labels, labels, stats, _ = cv2.connectedComponentsWithStats(face_raw, connectivity=8)
    if n_labels > 1:
        largest = 1 + np.argmax(stats[1:, cv2.CC_STAT_AREA])
        face_mask = ((labels == largest).astype(np.uint8)) * 255
    else:
        face_mask = face_raw

    # Expand face mask slightly to cover feature edges
    face_mask = cv2.dilate(face_mask, np.ones((5, 5), np.uint8), iterations=1)
    face_mask = face_mask & (fg * 255)

    # --- Hair: dark connected regions around/above face zone ---
    L_chan = lab[:, :, 0]
    dark = (L_chan < 60).astype(np.uint8)  # dark pixels in LAB lightness

    # Hair search zone: above face bottom + sides of face zone
    hair_zone = np.zeros((h, w), dtype=np.uint8)
    hair_zone[y_min:face_y_bot, x_min:x_max + 1] = 1  # above + around face
    # Also include a band beside the face
    hair_zone[face_y_top:face_y_bot, x_min:face_x_left] = 1
    hair_zone[face_y_top:face_y_bot, face_x_right:x_max + 1] = 1

    hair_raw = (dark & hair_zone & fg & (face_mask == 0)).astype(np.uint8) * 255
    hair_raw = cv2.morphologyEx(hair_raw, cv2.MORPH_CLOSE, k_close)
    hair_raw = cv2.morphologyEx(hair_raw, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))

    # Keep only components large enough to be hair (> 1% of foreground area)
    fg_area = np.sum(fg)
    min_hair_area = max(100, int(fg_area * 0.01))
    n_labels, labels, stats, _ = cv2.connectedComponentsWithStats(hair_raw, connectivity=8)
    hair_mask = np.zeros((h, w), dtype=np.uint8)
    for lbl in range(1, n_labels):
        if stats[lbl, cv2.CC_STAT_AREA] >= min_hair_area:
            hair_mask[labels == lbl] = 255

    # --- Clothing: remaining foreground not face or hair ---
    clothing_mask = ((fg * 255) & ~face_mask & ~hair_mask)
    clothing_mask = np.clip(clothing_mask, 0, 255).astype(np.uint8)

    return {"face_mask": face_mask, "hair_mask": hair_mask, "clothing_mask": clothing_mask}


# ---------------------------------------------------------------------------
# Region-aware portrait enhancement (background_only_mode only)
# ---------------------------------------------------------------------------
def _face_feature_submasks(face_mask: np.ndarray, lab: np.ndarray,
                           hsv: np.ndarray) -> tuple:
    """Build dark-feature, lip, and nose-edge sub-masks inside face_mask.
    Returns (dark_feature_mask, lip_mask, nose_edge_mask) as uint8 arrays."""
    h, w = face_mask.shape[:2]
    fb = face_mask > 127
    L = lab[:, :, 0]
    gray = L  # L channel is a good grayscale proxy

    # Face bounding box for relative positioning
    ys, xs = np.where(fb)
    fy_min, fy_max = ys.min(), ys.max()
    fx_min, fx_max = xs.min(), xs.max()
    face_h = fy_max - fy_min + 1
    face_w = fx_max - fx_min + 1

    # Edge map inside face (used by dark features and nose)
    L_blur = cv2.GaussianBlur(L, (3, 3), 0)
    edges = cv2.Canny(L_blur, 30, 100)
    edges_dilated = cv2.dilate(edges, np.ones((3, 3), np.uint8), iterations=1)
    face_edges = (edges_dilated > 0) & fb

    # --- A) dark_feature_mask: pupils, lashes, brows, nostril, beard edges ---
    # Low-L pixels near edges (avoids flat dark skin shadows)
    median_L = np.median(L[fb]) if np.any(fb) else 128
    dark_thresh = max(median_L - 35, 30)
    dark_pixels = (L < dark_thresh) & fb
    dark_feature_mask = (dark_pixels & face_edges).astype(np.uint8) * 255
    # Small dilation to cover full stroke width
    dark_feature_mask = cv2.dilate(dark_feature_mask, np.ones((3, 3), np.uint8), iterations=1)
    dark_feature_mask = dark_feature_mask & (face_mask)

    # --- B) lip_mask: red/pink-biased pixels in lower half of face ---
    lip_zone = np.zeros((h, w), dtype=bool)
    lip_y_top = fy_min + int(face_h * 0.55)
    lip_x_left = fx_min + int(face_w * 0.25)
    lip_x_right = fx_min + int(face_w * 0.75)
    lip_zone[lip_y_top:fy_max + 1, lip_x_left:lip_x_right] = True

    H = hsv[:, :, 0]
    S = hsv[:, :, 1]
    # Red/pink hue: 0-10 or 160-180 in OpenCV HSV, with moderate saturation
    red_hue = ((H <= 12) | (H >= 160)) & (S >= 40)
    # Must be more saturated than surrounding skin
    lip_mask = (red_hue & lip_zone & fb & (dark_feature_mask == 0)).astype(np.uint8) * 255
    # Clean up small noise
    k_small = np.ones((3, 3), np.uint8)
    lip_mask = cv2.morphologyEx(lip_mask, cv2.MORPH_CLOSE, k_small)
    lip_mask = cv2.morphologyEx(lip_mask, cv2.MORPH_OPEN, k_small)
    lip_mask = lip_mask & face_mask

    # --- C) nose_edge_mask: edge pixels in central-lower face, not already claimed ---
    nose_zone = np.zeros((h, w), dtype=bool)
    nose_y_top = fy_min + int(face_h * 0.35)
    nose_y_bot = fy_min + int(face_h * 0.70)
    nose_x_left = fx_min + int(face_w * 0.35)
    nose_x_right = fx_min + int(face_w * 0.65)
    nose_zone[nose_y_top:nose_y_bot, nose_x_left:nose_x_right] = True

    nose_edge_mask = (face_edges & nose_zone &
                      (dark_feature_mask == 0) & (lip_mask == 0)).astype(np.uint8) * 255

    return dark_feature_mask, lip_mask, nose_edge_mask


def enhance_face_region(image: np.ndarray, face_mask: np.ndarray) -> np.ndarray:
    """Feature-region-aware face enhancement for Wilcom stitch detection.
    Builds sub-masks for dark features (eyes/brows/nostrils), lips, and
    nose contour, then applies targeted LAB/HSV adjustments per region.
    Flat skin (cheeks, forehead) is untouched."""
    if not np.any(face_mask > 0):
        return image

    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

    dark_mask, lip_mask, nose_mask = _face_feature_submasks(face_mask, lab, hsv)

    L = lab[:, :, 0].astype(np.float32)
    S = hsv[:, :, 1].astype(np.float32)

    # --- A) Dark features: darken L by ~10%, mild local contrast ---
    dark_bool = dark_mask > 127
    if np.any(dark_bool):
        L[dark_bool] *= 0.90
        # Local contrast: push away from local mean
        local_mean = cv2.GaussianBlur(L, (15, 15), 0)
        L[dark_bool] = local_mean[dark_bool] + 1.08 * (L[dark_bool] - local_mean[dark_bool])

    # --- B) Lips: slight L darkening + saturation boost ---
    lip_bool = lip_mask > 127
    if np.any(lip_bool):
        L[lip_bool] *= 0.94
        S[lip_bool] = np.clip(S[lip_bool] * 1.15, 0, 255)

    # --- C) Nose contour: very subtle L darkening ---
    nose_bool = nose_mask > 127
    if np.any(nose_bool):
        L[nose_bool] *= 0.95

    # Write back
    lab[:, :, 0] = np.clip(L, 0, 255).astype(np.uint8)
    result = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)

    # Apply saturation changes (lips) via HSV round-trip
    if np.any(lip_bool):
        hsv[:, :, 1] = np.clip(S, 0, 255).astype(np.uint8)
        hsv_result = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)
        result[lip_bool] = hsv_result[lip_bool]

    return result


def refine_hair_region(image: np.ndarray, hair_mask: np.ndarray) -> np.ndarray:
    """Mild cleanup on hair region. Preserves silhouette and major structure.
    Only smooths tiny noise — does NOT flatten hair into a blob."""
    if not np.any(hair_mask > 0):
        return image

    # Very mild median blur (3x3) to reduce pixel noise
    smoothed = cv2.medianBlur(image, 3)
    result = image.copy()
    mask_bool = hair_mask > 127
    result[mask_bool] = smoothed[mask_bool]
    return result


def simplify_clothing_region(image: np.ndarray, clothing_mask: np.ndarray) -> np.ndarray:
    """Reduce micro-pattern noise in clothing while preserving folds and silhouette.
    Applies bilateral filtering only where local texture density is high."""
    if not np.any(clothing_mask > 0):
        return image

    cloth_bool = clothing_mask > 127

    # Detect high-frequency texture density inside clothing
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY).astype(np.float32)
    sx = cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3)
    sy = cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=3)
    mag = np.sqrt(sx * sx + sy * sy)
    mag_smooth = cv2.GaussianBlur(mag, (15, 15), 0)

    # Only smooth where texture is above median density within clothing
    cloth_mags = mag_smooth[cloth_bool]
    if len(cloth_mags) == 0:
        return image
    thresh = np.percentile(cloth_mags, 50)
    texture_hot = (mag_smooth > thresh) & cloth_bool

    if not np.any(texture_hot):
        return image

    # Two passes of bilateral for stronger texture reduction
    smoothed = cv2.bilateralFilter(image, 7, 45, 45)
    smoothed = cv2.bilateralFilter(smoothed, 5, 35, 35)

    result = image.copy()
    result[texture_hot] = smoothed[texture_hot]
    return result


def upscale_rgba(rgba: np.ndarray, target_width: int) -> np.ndarray:
    """Upscale an RGBA image to target_width preserving alpha, using Lanczos."""
    h, w = rgba.shape[:2]
    if w >= target_width:
        return rgba
    scale = target_width / w
    new_size = (target_width, int(h * scale))
    # Split channels, upscale separately to avoid alpha bleed
    rgb = rgba[:, :, :3]
    alpha = rgba[:, :, 3]
    rgb_up = cv2.resize(rgb, new_size, interpolation=cv2.INTER_LANCZOS4)
    alpha_up = cv2.resize(alpha, new_size, interpolation=cv2.INTER_LANCZOS4)
    return np.dstack([rgb_up, alpha_up])

def process_image(input_path: str, output_path: str | None = None,
                  config: dict | None = None) -> np.ndarray:
    if output_path is None:
        output_path = _default_output_path(input_path)

    cfg = {**DEFAULT_CONFIG, **(config or {})}
    # Backward compat: if caller sets "width" but not "working_width", use "width"
    if "working_width" not in (config or {}):
        cfg["working_width"] = cfg["width"]
    debug = cfg["debug"]
    ddir = cfg["debug_dir"]

    image = cv2.imread(input_path)
    if image is None:
        raise FileNotFoundError(f"Cannot read image: {input_path}")

    # 1. Resize to working width (internal processing resolution)
    image = resize_image(image, cfg["working_width"])
    original_resized = image.copy()

    # --- Background alpha extraction (shared by both modes) ---
    background_alpha = None
    if cfg["remove_bg"]:
        background_alpha = extract_background_alpha_from_original(
            original_resized,
            lab_tolerance=cfg["bg_lab_tolerance"]
        )

    # === BACKGROUND-ONLY MODE (recommended for portrait workflow) ===
    # Only: resize → alpha extraction → trim → premultiply → upscale → export
    # No quantization, cleanup, color merge, or outline reburn.
    if cfg["background_only_mode"]:
        result = original_resized.copy()
        if background_alpha is not None:
            background_alpha = trim_foreground_alpha(background_alpha, trim_px=2)

            # 1. Estimate portrait regions
            regions = estimate_portrait_regions(result, background_alpha)
            if debug:
                _debug_save(regions["face_mask"], ddir, "bg_region_face")
                _debug_save(regions["hair_mask"], ddir, "bg_region_hair")
                _debug_save(regions["clothing_mask"], ddir, "bg_region_clothing")

            # 2. Region-aware enhancements (on clean RGB before premultiply)
            if cfg.get("enable_face_enhancement", True):
                result = enhance_face_region(result, regions["face_mask"])
            if cfg.get("enable_hair_refinement", True):
                result = refine_hair_region(result, regions["hair_mask"])
            if cfg.get("enable_clothing_smoothing", True):
                result = simplify_clothing_region(result, regions["clothing_mask"])

            # 3. Premultiply + RGBA
            result = premultiply_rgb_with_alpha(result, background_alpha)
            result = np.dstack([result, background_alpha])
        # Upscale final RGBA to output_width for Wilcom auto-tracing
        if cfg["upscale_background_only"] and cfg["output_width"] > cfg.get("working_width", cfg["width"]):
            result = upscale_rgba(result, cfg["output_width"])
        if debug:
            _debug_save(result, ddir, "bg_only_output")
        save_output(result, output_path)
        return result

    # === FULL STYLIZATION MODE (optional embroidery simplification) ===
    # Use background_only_mode above for portrait-safe workflow.

    # Portrait-safe overrides: preserve more detail in full mode
    if cfg.get("portrait_safe_mode", True):
        if cfg["K"] < 12:
            cfg["K"] = 12

    if cfg["remove_bg"] and background_alpha is not None:
        fg_bool = background_alpha > 127
        image[~fg_bool] = [255, 255, 255]  # neutral background

    adaptive_min_area = int(0.0008 * image.shape[0] * image.shape[1])

    # 2. Extract outlines
    outline_mask = np.zeros(image.shape[:2], dtype=np.uint8)
    if cfg["enable_outlines"]:
        outline_mask = extract_outline_mask(image, cfg["dark_threshold"])
        outline_mask = normalize_outline(outline_mask, 2)
    if debug:
        _debug_save(outline_mask, ddir, "01_outline_mask")

    # 3. Extract white highlights (source from pre-modification original)
    white_mask = np.zeros(image.shape[:2], dtype=np.uint8)
    white_pixels = original_resized.copy()
    if cfg["enable_whites"]:
        white_mask = extract_white_mask(image, cfg["white_threshold"])
        kernel = np.ones((3, 3), np.uint8)
        white_mask = cv2.dilate(white_mask, kernel, iterations=1)
    if debug:
        _debug_save(white_mask, ddir, "02_white_mask")

    # 3b. Extract large light regions
    light_region_mask = np.zeros(image.shape[:2], dtype=np.uint8)
    if cfg["enable_whites"]:
        light_region_mask = extract_light_region_mask(image)
    if debug:
        _debug_save(light_region_mask, ddir, "02b_light_region_mask")

    # 4. Color layer
    color_layer = image.copy()
    if debug:
        _debug_save(color_layer, ddir, "03_color_layer")

    # 5. Bilateral filter
    if cfg["enable_smoothing"]:
        for _ in range(2):
            color_layer = apply_bilateral_filter(
                color_layer, cfg["bilateral_d"],
                cfg["bilateral_sigma_color"], cfg["bilateral_sigma_space"]
            )

    # 5b. Foreground mask for quantization
    fg_mask = background_alpha.copy() if background_alpha is not None else None

    # 6. K-means quantization (foreground only)
    if cfg["enable_quantization"]:
        color_layer = kmeans_quantization(color_layer, cfg["K"], fg_mask=fg_mask)
        if not cfg.get("portrait_safe_mode", False):
            color_layer = cv2.medianBlur(color_layer, 3)
    if debug:
        _debug_save(color_layer, ddir, "04_kmeans")

    # 7. Remove small noisy regions (foreground-aware)
    cleanup_min_area = adaptive_min_area
    if cfg.get("portrait_safe_mode", True):
        cleanup_min_area = max(1, cleanup_min_area // 5)  # less aggressive for portraits
    if cfg["enable_cleanup"] and cfg["enable_quantization"]:
        color_layer = remove_small_regions(color_layer, cleanup_min_area, fg_mask=fg_mask)
    if debug:
        _debug_save(color_layer, ddir, "05_region_cleanup")

    # 8. Morphological closing
    if cfg["enable_cleanup"] and cfg["enable_quantization"]:
        color_layer = apply_morphology(color_layer, cfg["morph_kernel_size"])

    # 9. Merge near-duplicates
    merge_dist = 6
    if cfg.get("portrait_safe_mode", True):
        merge_dist = 4  # tighter threshold to preserve clothing detail
    if cfg["enable_quantization"]:
        color_layer = merge_similar_colors(color_layer, min_distance=merge_dist)

    # 10. Composite
    result = composite_final(color_layer, outline_mask, white_mask, white_pixels)
    if np.any(light_region_mask):
        result[light_region_mask > 0] = [255, 255, 255]
    result[outline_mask > 0] = [0, 0, 0]
    if debug:
        _debug_save(result, ddir, "06_final")

    # 11. Apply background transparency
    if cfg["remove_bg"] and background_alpha is not None:
        background_alpha = trim_foreground_alpha(background_alpha, trim_px=2)
        background_alpha = cv2.GaussianBlur(background_alpha, (3, 3), 0)
        result = premultiply_rgb_with_alpha(result, background_alpha)
        result = np.dstack([result, background_alpha])
        if debug:
            _debug_save(background_alpha, ddir, "07_alpha_trimmed")
            _debug_save(result, ddir, "08_bg_removed")

    # 12. Save
    save_output(result, output_path)
    return result

# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="Preprocess LLM-generated portraits for embroidery digitizing."
    )
    parser.add_argument("input", help="Image name (looked up in images/ folder) or full path")
    parser.add_argument("-o", "--output", default=None,
                        help="Output path (default: generated/<name>_embroidery.png)")
    parser.add_argument("-K", type=int, default=6, help="Fill colors (default: 6)")
    parser.add_argument("-w", "--width", type=int, default=512, help="Resize width")
    parser.add_argument("--dark-threshold", type=int, default=80,
                        help="Outline extraction threshold (0-255)")
    parser.add_argument("--white-threshold", type=int, default=200,
                        help="White highlight threshold (0-255)")
    parser.add_argument("--no-remove-bg", action="store_true",
                        help="Skip background removal")
    parser.add_argument("--bg-only", action="store_true",
                        help="Background removal only — no stylization")
    parser.add_argument("--debug", action="store_true", help="Save intermediate outputs")
    parser.add_argument("--debug-dir", default="debug_output", help="Debug output dir")

    args = parser.parse_args()

    user_config = {
        "width": args.width,
        "K": args.K,
        "dark_threshold": args.dark_threshold,
        "white_threshold": args.white_threshold,
        "remove_bg": not args.no_remove_bg,
        "background_only_mode": args.bg_only,
        "debug": args.debug,
        "debug_dir": args.debug_dir,
    }

    input_path = _resolve_input_path(args.input)
    out = args.output or _default_output_path(input_path)
    process_image(input_path, out, user_config)
    print(f"Done → {out}")
