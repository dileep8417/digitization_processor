"""Flask web frontend for depth map generator."""

import uuid
import time
import threading
from pathlib import Path

from flask import Flask, render_template, request, jsonify, send_file

app = Flask(__name__)
app.config["UPLOAD_FOLDER"] = Path("uploads")
app.config["OUTPUT_FOLDER"] = Path("outputs")
app.config["MAX_CONTENT_LENGTH"] = 50 * 1024 * 1024  # 50MB

app.config["UPLOAD_FOLDER"].mkdir(exist_ok=True)
app.config["OUTPUT_FOLDER"].mkdir(exist_ok=True)

_jobs: dict[str, dict] = {}

ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".tiff", ".webp"}


def allowed_file(filename: str) -> bool:
    return Path(filename).suffix.lower() in ALLOWED_EXTENSIONS


def run_depth_job(job_id: str, input_path: str, output_path: str, settings: dict):
    try:
        _jobs[job_id]["status"] = "processing"
        _jobs[job_id]["stage"] = "Starting..."

        from depth_map import (Config, RunMode, estimate_depth,
                               save_depth_16bit, save_depth_preview_8bit,
                               save_shaded_preview)

        mode = RunMode(settings.get("mode", "final_quality"))
        cfg = Config(
            mode=mode,
            remove_bg=settings.get("remove_bg", True),
            print_mode=settings.get("print_mode", True),
            gamma=settings.get("gamma"),
            save_debug=settings.get("save_debug", False),
            use_print_heightmap=settings.get("use_print_heightmap", True),
            llm_relief_detail_strength=float(settings.get("detail_strength", 0.40)),
            llm_relief_contour_suppress=settings.get("contour_suppress", True),
        )
        cfg.apply_mode_defaults()

        t0 = time.time()

        def update_stage(msg: str):
            _jobs[job_id]["stage"] = msg

        depth, w, h = estimate_depth(input_path, cfg, stage_callback=update_stage)

        _jobs[job_id]["stage"] = "Saving 16-bit depth map..."
        save_depth_16bit(depth, output_path, w, h)

        preview_path = output_path.replace("_depth.png", "_preview.png")
        save_depth_preview_8bit(depth, preview_path, w, h)
        _jobs[job_id]["preview_path"] = preview_path

        shaded_path = output_path.replace("_depth.png", "_shaded.png")
        save_shaded_preview(depth, shaded_path, w, h)
        _jobs[job_id]["shaded_path"] = shaded_path

        elapsed = time.time() - t0
        _jobs[job_id]["status"] = "done"
        _jobs[job_id]["stage"] = f"Complete ({elapsed:.1f}s)"
        _jobs[job_id]["elapsed"] = round(elapsed, 1)

    except Exception as e:
        _jobs[job_id]["status"] = "error"
        _jobs[job_id]["stage"] = str(e)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/generate", methods=["POST"])
def generate():
    if "image" not in request.files:
        return jsonify({"error": "No image uploaded"}), 400

    file = request.files["image"]
    if not file.filename or not allowed_file(file.filename):
        return jsonify({"error": "Invalid file type. Use JPG, PNG, BMP, TIFF, or WebP."}), 400

    job_id = str(uuid.uuid4())[:8]
    ext = Path(file.filename).suffix.lower()
    input_path = str(app.config["UPLOAD_FOLDER"] / f"{job_id}_input{ext}")
    output_path = str(app.config["OUTPUT_FOLDER"] / f"{job_id}_depth.png")
    file.save(input_path)

    gamma_val = request.form.get("gamma")

    settings = {
        "mode": request.form.get("mode", "final_quality"),
        "remove_bg": request.form.get("remove_bg", "true") == "true",
        "print_mode": request.form.get("print_mode", "true") == "true",
        "save_debug": request.form.get("save_debug", "false") == "true",
        "use_print_heightmap": request.form.get("use_print_heightmap", "true") == "true",
        "gamma": float(gamma_val) if gamma_val else None,
        "detail_strength": float(request.form.get("detail_strength", 0.40)),
        "contour_suppress": request.form.get("contour_suppress", "true") == "true",
    }

    _jobs[job_id] = {
        "status": "queued",
        "stage": "Queued...",
        "input_path": input_path,
        "output_path": output_path,
    }

    thread = threading.Thread(target=run_depth_job,
                              args=(job_id, input_path, output_path, settings))
    thread.start()
    return jsonify({"job_id": job_id})


@app.route("/api/status/<job_id>")
def job_status(job_id):
    job = _jobs.get(job_id)
    if not job:
        return jsonify({"error": "Job not found"}), 404
    return jsonify({
        "status": job["status"],
        "stage": job["stage"],
        "elapsed": job.get("elapsed"),
    })


@app.route("/api/download/<job_id>")
def download(job_id):
    job = _jobs.get(job_id)
    if not job or job["status"] != "done":
        return jsonify({"error": "Not ready"}), 404
    return send_file(job["output_path"], as_attachment=True,
                     download_name=f"depth_{job_id}.png")


@app.route("/api/preview/<job_id>")
def preview(job_id):
    job = _jobs.get(job_id)
    if not job or job["status"] != "done":
        return jsonify({"error": "Not ready"}), 404
    preview_path = job.get("preview_path")
    if preview_path and Path(preview_path).exists():
        return send_file(preview_path, mimetype="image/png")
    return send_file(job["output_path"], mimetype="image/png")


@app.route("/api/shaded/<job_id>")
def shaded(job_id):
    job = _jobs.get(job_id)
    if not job or job["status"] != "done":
        return jsonify({"error": "Not ready"}), 404
    shaded_path = job.get("shaded_path")
    if shaded_path and Path(shaded_path).exists():
        return send_file(shaded_path, mimetype="image/png")
    return jsonify({"error": "Shaded preview not available"}), 404


if __name__ == "__main__":
    print("Starting Depth Map Generator Web UI...")
    print("Open http://localhost:5000 in your browser")
    app.run(host="0.0.0.0", port=5000, debug=False)
