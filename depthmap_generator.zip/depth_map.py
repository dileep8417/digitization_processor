"""
Depth map generator for FDM bas-relief printing.

Pipeline (LLM Relief):
    LLM sculptural image → Depth Anything V2 → normalize → border halo suppression
    → smooth → detail recovery → contour suppression → contrast → feather
    → print heightmap → 16-bit export

Usage:
    python depth_map.py input.jpg --remove-bg --print-mode
    python depth_map.py input.jpg --remove-bg --print-mode --mode final_quality
    python depth_map.py input.jpg --remove-bg --print-mode --save-debug
"""

from __future__ import annotations

import argparse
import os
import ssl
import time
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

# SSL workaround for corporate VPN/proxy — must be set before huggingface_hub is imported
os.environ["CURL_CA_BUNDLE"] = ""
os.environ["REQUESTS_CA_BUNDLE"] = ""
os.environ["HF_HUB_DISABLE_SSL_VERIFY"] = "1"
ssl._create_default_https_context = ssl._create_unverified_context

# Monkey-patch httpx to skip SSL (huggingface_hub uses httpx internally)
import httpx as _httpx
_orig_client_init = _httpx.Client.__init__
_orig_async_init = _httpx.AsyncClient.__init__
def _patched_client_init(self, *args, **kwargs):
    kwargs["verify"] = False
    return _orig_client_init(self, *args, **kwargs)
def _patched_async_init(self, *args, **kwargs):
    kwargs["verify"] = False
    return _orig_async_init(self, *args, **kwargs)
_httpx.Client.__init__ = _patched_client_init
_httpx.AsyncClient.__init__ = _patched_async_init

import cv2
import numpy as np
from PIL import Image


# ---------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------

class RunMode(Enum):
    FAST_PREVIEW = "fast_preview"
    BALANCED = "balanced"
    FINAL_QUALITY = "final_quality"



# Inference defaults per mode (Depth Anything V2 — no Marigold)
MODE_DEFAULTS: dict[RunMode, dict] = {
    RunMode.FAST_PREVIEW:  {"inference_max_side": 768},
    RunMode.BALANCED:      {"inference_max_side": 1024},
    RunMode.FINAL_QUALITY: {"inference_max_side": 1280},
}


@dataclass
class Config:
    mode: RunMode = RunMode.FINAL_QUALITY
    inference_max_side: int = 1280
    remove_bg: bool = True
    print_mode: bool = True
    gamma: float | None = None
    save_debug: bool = False
    debug_dir: str = "debug_depth"

    # Silhouette feathering
    feather_pct: float = 0.005

    # Phase 3: Print-aware heightmap
    use_print_heightmap: bool = True
    base_height_mm: float = 0.7
    relief_height_mm: float = 2.5
    height_gamma: float = 1.0
    edge_bevel_px: int = 10

    # Detail recovery
    llm_relief_detail_strength: float = 0.40
    llm_relief_detail_mode: str = "sculpt"  # "safe" or "sculpt"
    llm_relief_detail_blur_sigma: float = 6.0
    llm_relief_final_bilateral_d: int = 5
    llm_relief_final_bilateral_sigma_color: float = 0.035
    llm_relief_final_bilateral_sigma_space: float = 5.0

    # Contour suppression
    llm_relief_contour_suppress: bool = True
    llm_relief_contour_strength: float = 0.65

    def apply_mode_defaults(self) -> None:
        for key, val in MODE_DEFAULTS[self.mode].items():
            setattr(self, key, val)


# ---------------------------------------------------------------------
# Utils
# ---------------------------------------------------------------------

class Timer:
    def __init__(self):
        self._start = time.time()
        self._last = self._start

    def log(self, stage: str) -> None:
        now = time.time()
        print(f"  [{stage}] {now - self._last:.2f}s")
        self._last = now

    def total(self) -> float:
        return time.time() - self._start


def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def save_debug(name: str, img: np.ndarray, cfg: Config) -> None:
    if not cfg.save_debug:
        return
    ensure_dir(cfg.debug_dir)
    if img.dtype != np.uint8:
        if img.dtype == bool:
            out = img.astype(np.uint8) * 255
        else:
            arr = img.astype(np.float32)
            arr -= arr.min()
            if arr.max() > 0:
                arr /= arr.max()
            out = (arr * 255).astype(np.uint8)
    else:
        out = img
    cv2.imwrite(str(Path(cfg.debug_dir) / f"{name}.png"), out)


def log_depth_stats(name: str, arr: np.ndarray, mask: np.ndarray) -> None:
    vals = arr[mask]
    if vals.size == 0:
        print(f"  [STATS] {name}: EMPTY MASK")
        return
    rounded_unique = len(np.unique(np.round(vals, 4)))
    print(f"  [STATS] {name}: "
          f"min={vals.min():.4f}, max={vals.max():.4f}, "
          f"mean={vals.mean():.4f}, std={vals.std():.4f}, "
          f"p2={np.percentile(vals, 2):.4f}, p50={np.percentile(vals, 50):.4f}, "
          f"p98={np.percentile(vals, 98):.4f}, unique4={rounded_unique}")


def get_device() -> str:
    import torch
    if torch.cuda.is_available():
        return "cuda"
    if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
        return "mps"
    return "cpu"


def resize_for_inference(img: np.ndarray, max_side: int) -> tuple[np.ndarray, tuple[int, int]]:
    h, w = img.shape[:2]
    if max(h, w) <= max_side:
        return img, (h, w)
    scale = max_side / max(h, w)
    return cv2.resize(img, (int(w * scale), int(h * scale)),
                      interpolation=cv2.INTER_AREA), (h, w)


def load_image(path: str) -> np.ndarray:
    raw = cv2.imread(path)
    if raw is None:
        raise FileNotFoundError(f"Cannot read image: {path}")
    return raw


# ---------------------------------------------------------------------
# Foreground masking
# ---------------------------------------------------------------------

def get_fg_mask(img_path: str, target_hw: tuple[int, int]) -> np.ndarray:
    """Foreground mask using rembg (U²-Net)."""
    from rembg import remove as remove_bg
    rgba = remove_bg(Image.open(img_path))
    alpha = np.array(rgba.split()[3]) > 128
    return np.array(
        Image.fromarray(alpha.astype(np.uint8) * 255).resize(
            (target_hw[1], target_hw[0]), Image.NEAREST)
    ) > 128


# ---------------------------------------------------------------------
# Depth Anything V2 inference
# ---------------------------------------------------------------------

def infer_depth_anything(raw_bgr: np.ndarray, max_side: int = 1280) -> np.ndarray:
    """Run Depth Anything V2 inference. Returns float32 depth in [0, 1]."""
    from depth_models.depth_anything import infer_depth_anything as _infer_da
    return _infer_da(raw_bgr, max_side=max_side)


# ---------------------------------------------------------------------
# Face detection
# ---------------------------------------------------------------------

def detect_faces(raw_bgr: np.ndarray, target_hw: tuple[int, int]
                 ) -> list[tuple[int, int, int, int]]:
    """Detect faces using OpenCV DNN face detector.

    Returns list of (x, y, w, h) bounding boxes in target_hw coordinates.
    Uses the built-in Yunet face detector (ships with opencv-python >= 4.8).
    Falls back to Haar cascade if Yunet is unavailable.
    """
    h, w = raw_bgr.shape[:2]
    th, tw = target_hw
    sx, sy = tw / w, th / h

    boxes = []

    # Try Yunet (more accurate, available in opencv >= 4.8)
    try:
        detector = cv2.FaceDetectorYN.create(
            cv2.data.haarcascades + "../face_detection_yunet_2023mar.onnx",
            "", (w, h), 0.5, 0.3, 5000,
        )
        _, faces = detector.detect(raw_bgr)
        if faces is not None:
            for face in faces:
                fx, fy, fw, fh = int(face[0]), int(face[1]), int(face[2]), int(face[3])
                boxes.append((int(fx * sx), int(fy * sy), int(fw * sx), int(fh * sy)))
            if boxes:
                print(f"  [Face detect] Yunet found {len(boxes)} face(s)")
                return boxes
    except Exception:
        pass

    # Fallback: Haar cascade (always available)
    try:
        cascade_path = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
        cascade = cv2.CascadeClassifier(cascade_path)
        gray = cv2.cvtColor(raw_bgr, cv2.COLOR_BGR2GRAY)
        detections = cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=4,
                                               minSize=(int(w * 0.08), int(h * 0.08)))
        for (fx, fy, fw, fh) in detections:
            boxes.append((int(fx * sx), int(fy * sy), int(fw * sx), int(fh * sy)))
        if boxes:
            print(f"  [Face detect] Haar found {len(boxes)} face(s)")
    except Exception as e:
        print(f"  [Face detect] Failed: {e}")

    return boxes


def build_face_mask(face_boxes: list[tuple[int, int, int, int]],
                    shape: tuple[int, int], expand: float = 0.3,
                    sigma: float = 15.0) -> np.ndarray:
    """Build a soft face region mask from detected bounding boxes.

    Returns float32 mask in [0, 1] where 1 = face center, tapering to 0.
    Boxes are expanded by `expand` fraction to cover forehead/chin.
    """
    h, w = shape
    mask = np.zeros((h, w), dtype=np.float32)
    if not face_boxes:
        return mask

    for (bx, by, bw, bh) in face_boxes:
        # Expand box to cover forehead and chin
        ex = int(bw * expand * 0.5)
        ey = int(bh * expand)
        x1 = max(0, bx - ex)
        y1 = max(0, by - ey)
        x2 = min(w, bx + bw + ex)
        y2 = min(h, by + bh + int(ey * 0.5))
        mask[y1:y2, x1:x2] = 1.0

    # Soften edges with Gaussian blur
    mask = cv2.GaussianBlur(mask, (0, 0), sigmaX=sigma)
    return np.clip(mask, 0.0, 1.0)


# ---------------------------------------------------------------------
# Contour suppression (from Premium branch — proven effective)
# ---------------------------------------------------------------------

def suppress_contours(
    height: np.ndarray, fg_mask: np.ndarray, strength: float = 0.7,
) -> np.ndarray:
    """Suppress contour/banding artifacts using targeted smoothing.

    Two-stage approach:
    1. Large bilateral filter for global surface smoothing (preserves major edges)
    2. Targeted Laplacian-guided blending at high-curvature pixels
    """
    out = height.copy().astype(np.float32)
    if not np.any(fg_mask):
        return out

    # Stage 1: Large bilateral filter
    bilateral = cv2.bilateralFilter(out, d=21, sigmaColor=0.05, sigmaSpace=21)
    bilateral[~fg_mask] = 0.0

    base_blend = strength * 0.6
    out[fg_mask] = (1.0 - base_blend) * out[fg_mask] + base_blend * bilateral[fg_mask]

    # Stage 2: Extra smoothing at high-curvature points
    lap = cv2.Laplacian(out, cv2.CV_32F, ksize=3)
    lap_mag = np.abs(lap)
    lap_vals = lap_mag[fg_mask]
    if lap_vals.size == 0:
        return out

    lap_p80 = np.percentile(lap_vals, 80)
    if lap_p80 < 1e-6:
        return out

    very_smooth = cv2.GaussianBlur(out, (0, 0), sigmaX=6)
    very_smooth[~fg_mask] = 0.0

    curvature_weight = np.clip((lap_mag - lap_p80) / (lap_p80 + 1e-6), 0.0, 1.0)
    curvature_weight = curvature_weight * strength * 0.4
    curvature_weight = cv2.GaussianBlur(curvature_weight, (0, 0), sigmaX=2.0)
    curvature_weight = np.clip(curvature_weight, 0.0, strength * 0.4)
    curvature_weight[~fg_mask] = 0.0

    out = out * (1.0 - curvature_weight) + very_smooth * curvature_weight
    out[~fg_mask] = 0.0
    return out


# ---------------------------------------------------------------------
# LLM Relief pipeline functions
# ---------------------------------------------------------------------

def _normalize(depth: np.ndarray, fg_mask: np.ndarray) -> np.ndarray:
    """Normalize depth within foreground using percentile stretch."""
    out = depth.copy()
    if not np.any(fg_mask):
        return out
    vals = out[fg_mask]
    p2, p98 = np.percentile(vals, (2, 98))
    rng = p98 - p2
    if rng < 1e-6:
        return out
    out[fg_mask] = np.clip((vals - p2) / (rng + 1e-8), 0.0, 1.0)
    out[~fg_mask] = 0.0
    return out


def _weighted_mean(arr: np.ndarray, weight: np.ndarray, eps: float = 1e-6) -> float:
    """Compute weighted mean of arr using weight mask."""
    s = float(np.sum(weight))
    if s < eps:
        return 0.0
    return float(np.sum(arr * weight) / s)

def _rebalance_face_cloth(
    depth: np.ndarray, fg_mask: np.ndarray, cfg: Config,
    face_mask: np.ndarray | None = None,
) -> np.ndarray:
    """Correct face/body depth hierarchy for portrait bas-relief.

    Face-aware path:
        If a valid face_mask is available, compare actual detected face/head
        regions against supporting body/clothing regions using weighted means.
        The goal is not just "body should not be above face"; for portrait
        relief, face should sit slightly above body/supporting mass.

    Fallback path:
        If face_mask is missing/invalid, use the previous vertical ramp
        heuristic unchanged.

    This function is intentionally conservative for FDM:
        - no hard masks
        - no facial landmark sculpting
        - no global contrast
        - no new dependencies
        - background remains zero
    """
    out = depth.copy().astype(np.float32)
    if not np.any(fg_mask):
        return out

    h, w = depth.shape[:2]
    fg_float = fg_mask.astype(np.float32)
    fg_count = float(np.sum(fg_mask))

    # Foreground vertical extent, needed for fallback and blur scale.
    fg_ys = np.where(fg_mask.any(axis=1))[0]
    if fg_ys.size < 10:
        return out

    fg_top, fg_bot = fg_ys[0], fg_ys[-1]
    fg_h = fg_bot - fg_top
    if fg_h < 20:
        return out

    # ------------------------------------------------------------------
    # Path 1: Face-mask-aware rebalance
    # ------------------------------------------------------------------
    use_face_mask = False
    face_soft = None

    if face_mask is not None:
        # Defensive normalization: accept float/bool/uint masks safely.
        fm = np.asarray(face_mask, dtype=np.float32)
        if fm.shape[:2] == out.shape[:2]:
            fm = np.nan_to_num(fm, nan=0.0, posinf=1.0, neginf=0.0)
            fm = np.clip(fm, 0.0, 1.0) * fg_float

            face_coverage = float(np.sum(fm > 0.10)) / max(fg_count, 1.0)

            if 0.02 <= face_coverage <= 0.45:
                face_soft = fm
                use_face_mask = True
            elif face_coverage > 0.45:
                # If the mask is too broad, tighten it before giving up.
                fm_tight = np.clip(fm - 0.30, 0.0, 1.0) * fg_float
                tight_coverage = float(np.sum(fm_tight > 0.10)) / max(fg_count, 1.0)

                if 0.02 <= tight_coverage <= 0.45:
                    face_soft = fm_tight
                    face_coverage = tight_coverage
                    use_face_mask = True
                else:
                    print(
                        f"  [Rebalance/face-aware] skipped: face mask too large "
                        f"coverage={face_coverage * 100:.1f}% "
                        f"tight={tight_coverage * 100:.1f}%"
                    )
            else:
                print(
                    f"  [Rebalance/face-aware] skipped: face mask too small "
                    f"coverage={face_coverage * 100:.1f}%"
                )

    if use_face_mask and face_soft is not None:
        # Normalize so the central face region has strong but soft weight.
        fm_max = float(face_soft.max())
        if fm_max <= 1e-6:
            print("  [Rebalance/face-aware] skipped: empty normalized face mask")
            return out

        face_soft = face_soft / fm_max
        face_soft = cv2.GaussianBlur(face_soft, (0, 0), sigmaX=max(4, fg_h * 0.015))
        face_soft = np.clip(face_soft, 0.0, 1.0)
        face_soft[~fg_mask] = 0.0

        # Body/support mask. This is NOT a hard inverse mask.
        # It remains soft so clothing/arms/hands are compressed gently only.
        body_soft = fg_float * (1.0 - face_soft)
        body_soft = cv2.GaussianBlur(body_soft, (0, 0), sigmaX=6)
        body_soft = np.clip(body_soft, 0.0, 1.0)
        body_soft[~fg_mask] = 0.0

        # Validate usable weights.
        if np.sum(face_soft) < 1e-6 or np.sum(body_soft) < 1e-6:
            print("  [Rebalance/face-aware] skipped: invalid face/body weights")
            return out

        face_mean = _weighted_mean(out, face_soft)
        body_mean = _weighted_mean(out, body_soft)

        # Portrait-specific target:
        # face should be slightly above body/supporting mass.
        target_margin = 0.04
        gap = (body_mean + target_margin) - face_mean

        if gap <= 0.0:
            print(
                f"  [Rebalance/face-aware] no-op: face already prioritized "
                f"face={face_mean:.3f} body={body_mean:.3f} "
                f"target_margin={target_margin:.3f} gap={gap:.3f}"
            )
            save_debug("04c_face_soft", face_soft, cfg)
            save_debug("04d_body_soft", body_soft, cfg)
            return out

        # Conservative separate corrections.
        # Separate face_lift/body_drop is safer than a single signed ramp,
        # because it avoids aggressively pushing down all non-face regions.
        face_lift = min(0.10, 0.50 * gap)
        body_drop = min(0.05, 0.25 * gap)

        candidate = out.copy()
        candidate += face_soft * face_lift
        candidate -= body_soft * body_drop
        candidate[fg_mask] = np.clip(candidate[fg_mask], 0.0, 1.0)
        candidate[~fg_mask] = 0.0

        # Safety: avoid excessive clipping in face region.
        face_region = (face_soft > 0.20) & fg_mask
        if np.any(face_region):
            clipped_pct = float(np.mean(candidate[face_region] >= 0.995)) * 100.0
            if clipped_pct > 3.0:
                # Reduce correction instead of failing hard.
                reduce = 0.60
                face_lift *= reduce
                body_drop *= reduce
                candidate = out.copy()
                candidate += face_soft * face_lift
                candidate -= body_soft * body_drop
                candidate[fg_mask] = np.clip(candidate[fg_mask], 0.0, 1.0)
                candidate[~fg_mask] = 0.0
                print(
                    f"  [Rebalance/face-aware] correction reduced due to clipping "
                    f"clipped={clipped_pct:.1f}%"
                )

        new_face_mean = _weighted_mean(candidate, face_soft)
        new_body_mean = _weighted_mean(candidate, body_soft)
        new_gap = (new_body_mean + target_margin) - new_face_mean

        print(
            f"  [Rebalance/face-aware] coverage={(np.sum(face_soft > 0.10) / max(fg_count, 1.0)) * 100:.1f}%"
        )
        print(
            f"  [Rebalance/face-aware] before: "
            f"face={face_mean:.3f} body={body_mean:.3f} "
            f"target_margin={target_margin:.3f} gap={gap:.3f}"
        )
        print(
            f"  [Rebalance/face-aware] applied: "
            f"face_lift={face_lift:.3f} body_drop={body_drop:.3f}"
        )
        print(
            f"  [Rebalance/face-aware] after: "
            f"face={new_face_mean:.3f} body={new_body_mean:.3f} "
            f"gap={new_gap:.3f}"
        )

        save_debug("04c_face_soft", face_soft, cfg)
        save_debug("04d_body_soft", body_soft, cfg)
        save_debug("04e_face_priority_rebalanced", candidate, cfg)
        save_debug("04c_rebalanced", candidate, cfg)

        return candidate

    # ------------------------------------------------------------------
    # Path 2: Fallback vertical heuristic
    # Kept close to your previous behavior for safety.
    # ------------------------------------------------------------------

    upper_cut = fg_top + int(fg_h * 0.40)
    lower_cut = fg_top + int(fg_h * 0.60)

    face_zone = fg_mask.copy()
    face_zone[upper_cut:, :] = False

    cloth_zone = fg_mask.copy()
    cloth_zone[:lower_cut, :] = False

    if not np.any(face_zone) or not np.any(cloth_zone):
        return out

    face_mean = float(np.mean(out[face_zone]))
    cloth_mean = float(np.mean(out[cloth_zone]))

    imbalance = cloth_mean - face_mean
    if imbalance < 0.08:
        return out

    ramp = np.zeros((h, w), dtype=np.float32)
    face_center_t = 0.30

    for y in range(fg_top, fg_bot + 1):
        t = (y - fg_top) / (fg_h + 1e-6)
        if t <= face_center_t:
            ramp[y, :] = 0.3 + 0.7 * (t / face_center_t)
        else:
            progress = (t - face_center_t) / (1.0 - face_center_t)
            ramp[y, :] = 1.0 - 2.0 * progress

    ramp[~fg_mask] = 0.0
    ramp = cv2.GaussianBlur(ramp, (0, 0), sigmaX=max(8, fg_h * 0.08))
    ramp[~fg_mask] = 0.0

    correction = min(imbalance * 0.35, 0.18)

    out[fg_mask] = out[fg_mask] + ramp[fg_mask] * correction
    out[fg_mask] = np.clip(out[fg_mask], 0.0, 1.0)
    out[~fg_mask] = 0.0

    new_face_mean = float(np.mean(out[face_zone]))
    new_cloth_mean = float(np.mean(out[cloth_zone]))

    print(
        f"  [Rebalance/fallback] face {face_mean:.3f}→{new_face_mean:.3f}  "
        f"cloth {cloth_mean:.3f}→{new_cloth_mean:.3f}  "
        f"gap {imbalance:.3f}→{new_cloth_mean - new_face_mean:.3f}"
    )

    save_debug("04c_rebalanced", out, cfg)
    return out

def _suppress_border_halo(
    depth: np.ndarray, fg_mask: np.ndarray, cfg: Config,
) -> np.ndarray:
    """Suppress the raised border/halo artifact created by depth models.

    Depth models often interpret the luminance gradient at the foreground
    edge as a depth step, creating a raised ring around the subject.
    Detects and reduces the border toward the background level if raised.
    Only activates when a halo is detected — no effect on clean inputs.
    """
    out = depth.copy()
    h, w = depth.shape[:2]
    if not np.any(fg_mask):
        return out

    dist = cv2.distanceTransform(fg_mask.astype(np.uint8) * 255, cv2.DIST_L2, 5)

    border_px = max(8, int(min(h, w) * 0.08))
    interior_px = max(16, int(min(h, w) * 0.15))

    border_ring = fg_mask & (dist >= 3) & (dist < border_px)
    background_zone = fg_mask & (dist >= border_px) & (dist < interior_px)

    if not np.any(border_ring) or not np.any(background_zone):
        return out

    border_mean = float(np.mean(out[border_ring]))
    bg_mean = float(np.mean(out[background_zone]))

    halo_excess = border_mean - bg_mean
    if halo_excess < 0.03:
        return out

    ramp = np.clip(dist / (border_px + 1e-6), 0.0, 1.0).astype(np.float32)
    ramp[~fg_mask] = 0.0

    halo_mask = border_ring & (out > bg_mean + 0.02)
    if not np.any(halo_mask):
        return out

    correction_strength = np.clip(1.0 - ramp, 0.0, 0.7)
    correction_strength[~halo_mask] = 0.0
    correction_strength = cv2.GaussianBlur(correction_strength, (0, 0), sigmaX=4)
    correction_strength[~fg_mask] = 0.0

    target = np.full_like(out, bg_mean)
    out = out * (1.0 - correction_strength) + target * correction_strength
    out[~fg_mask] = 0.0

    save_debug("04b_border_halo_suppressed", out, cfg)

    new_border_mean = float(np.mean(out[border_ring]))
    halo_pct = float(np.sum(halo_mask)) / float(np.sum(fg_mask)) * 100
    print(f"  [Border halo] suppressed: {halo_pct:.1f}% of fg, "
          f"border {border_mean:.3f} → {new_border_mean:.3f} (bg={bg_mean:.3f})")

    return out


def _smooth(depth: np.ndarray, fg_mask: np.ndarray,
            face_mask: np.ndarray | None = None) -> np.ndarray:
    """Edge-preserving smoothing. Bilateral + median + light Gaussian.
    If face_mask is provided, reduces smoothing inside face regions."""
    out = depth.copy()
    if not np.any(fg_mask):
        return out

    f32 = out.astype(np.float32)

    # Median blur to remove micro-island noise
    u8 = (np.clip(f32, 0, 1) * 255).astype(np.uint8)
    med = cv2.medianBlur(u8, 5).astype(np.float32) / 255.0
    out[fg_mask] = 0.7 * f32[fg_mask] + 0.3 * med[fg_mask]

    # Bilateral filter — edge-preserving
    out = cv2.bilateralFilter(out.astype(np.float32), d=9, sigmaColor=0.06, sigmaSpace=9)

    # Light Gaussian for body smoothness — reduced inside face regions
    smooth = cv2.GaussianBlur(out.astype(np.float32), (0, 0), sigmaX=4)
    if face_mask is not None and np.any(face_mask > 0.1):
        # face_mask=0 → 20% Gaussian (body), face_mask=1 → 5% Gaussian (face)
        blend = 0.20 - face_mask * 0.15
        blend[~fg_mask] = 0.0
        out[fg_mask] = (1.0 - blend[fg_mask]) * out[fg_mask] + blend[fg_mask] * smooth[fg_mask]
    else:
        out[fg_mask] = 0.8 * out[fg_mask] + 0.2 * smooth[fg_mask]

    out[~fg_mask] = 0.0
    return out


def _detail_recovery(
    depth: np.ndarray, raw_bgr: np.ndarray, fg_mask: np.ndarray, cfg: Config,
    face_mask: np.ndarray | None = None,
) -> np.ndarray:
    """Recover sculptural detail from input luminance.
    Dispatches to safe or sculpt mode."""
    if cfg.llm_relief_detail_mode == "sculpt":
        return _detail_sculpt(depth, raw_bgr, fg_mask, cfg, face_mask=face_mask)
    return _detail_safe(depth, raw_bgr, fg_mask, cfg)


def _detail_safe(
    depth: np.ndarray, raw_bgr: np.ndarray, fg_mask: np.ndarray, cfg: Config,
) -> np.ndarray:
    """Conservative detail recovery (band-pass weighted by depth gradient)."""
    out = depth.copy()
    h, w = depth.shape[:2]
    strength = cfg.llm_relief_detail_strength

    if strength <= 0 or not np.any(fg_mask):
        return out

    gray = cv2.cvtColor(raw_bgr, cv2.COLOR_BGR2GRAY).astype(np.float32) / 255.0
    if gray.shape[:2] != (h, w):
        gray = cv2.resize(gray, (w, h), interpolation=cv2.INTER_LINEAR)

    fg_gray = gray[fg_mask]
    if fg_gray.size == 0:
        return out
    g_p2, g_p98 = np.percentile(fg_gray, (2, 98))
    g_rng = g_p98 - g_p2
    if g_rng < 1e-6:
        return out
    lum_norm = np.zeros_like(gray)
    lum_norm[fg_mask] = np.clip((gray[fg_mask] - g_p2) / (g_rng + 1e-8), 0.0, 1.0)

    sigma_detail = cfg.llm_relief_detail_blur_sigma
    sigma_base = sigma_detail * 3.0
    lum_small = cv2.GaussianBlur(lum_norm, (0, 0), sigmaX=sigma_detail)
    lum_large = cv2.GaussianBlur(lum_norm, (0, 0), sigmaX=sigma_base)
    detail_raw = lum_small - lum_large

    dist = cv2.distanceTransform(fg_mask.astype(np.uint8) * 255, cv2.DIST_L2, 5)
    edge_guard_px = max(4, int(min(h, w) * 0.015))
    edge_weight = np.clip(dist / edge_guard_px, 0.0, 1.0).astype(np.float32)
    detail_raw = detail_raw * edge_weight

    detail_clipped = np.clip(detail_raw, -0.08, 0.08)
    detail_final = cv2.GaussianBlur(detail_clipped, (0, 0), sigmaX=2.0)

    depth_grad = cv2.GaussianBlur(out.astype(np.float32), (0, 0), sigmaX=3)
    gx = cv2.Sobel(depth_grad, cv2.CV_32F, 1, 0, ksize=3)
    gy = cv2.Sobel(depth_grad, cv2.CV_32F, 0, 1, ksize=3)
    grad_mag = np.sqrt(gx ** 2 + gy ** 2)
    g_max = grad_mag[fg_mask].max() if np.any(fg_mask) else 1.0
    if g_max > 1e-6:
        structure_weight = np.clip(grad_mag / g_max, 0.0, 1.0)
    else:
        structure_weight = np.ones_like(grad_mag)
    structure_weight = 0.3 + 0.7 * structure_weight
    structure_weight[~fg_mask] = 0.0

    detail_weighted = detail_final * structure_weight * strength
    out[fg_mask] = np.clip(out[fg_mask] + detail_weighted[fg_mask], 0.0, 1.0)

    out = cv2.bilateralFilter(
        out.astype(np.float32),
        d=cfg.llm_relief_final_bilateral_d,
        sigmaColor=cfg.llm_relief_final_bilateral_sigma_color,
        sigmaSpace=cfg.llm_relief_final_bilateral_sigma_space,
    )
    out[~fg_mask] = 0.0
    return out


def _detail_sculpt(
    depth: np.ndarray, raw_bgr: np.ndarray, fg_mask: np.ndarray, cfg: Config,
    face_mask: np.ndarray | None = None,
) -> np.ndarray:
    """Sculpt-mode detail recovery: stronger band-pass from input luminance,
    weighted by mixed confidence mask (interior distance + input gradient).
    If face_mask is provided, boosts strength inside face regions."""
    out = depth.copy()
    h, w = depth.shape[:2]
    strength = cfg.llm_relief_detail_strength

    if strength <= 0 or not np.any(fg_mask):
        return out

    # Luminance from input
    gray = cv2.cvtColor(raw_bgr, cv2.COLOR_BGR2GRAY).astype(np.float32) / 255.0
    if gray.shape[:2] != (h, w):
        gray = cv2.resize(gray, (w, h), interpolation=cv2.INTER_LINEAR)

    fg_gray = gray[fg_mask]
    if fg_gray.size == 0:
        return out
    g_p2, g_p98 = np.percentile(fg_gray, (2, 98))
    g_rng = g_p98 - g_p2
    if g_rng < 1e-6:
        return out
    lum_norm = np.zeros_like(gray)
    lum_norm[fg_mask] = np.clip((gray[fg_mask] - g_p2) / (g_rng + 1e-8), 0.0, 1.0)

    # Band-pass detail layer
    sigma_small = 2.0
    sigma_large = 24.0
    lum_small = cv2.GaussianBlur(lum_norm, (0, 0), sigmaX=sigma_small)
    lum_large = cv2.GaussianBlur(lum_norm, (0, 0), sigmaX=sigma_large)
    detail_raw = lum_small - lum_large

    # Suppress high-frequency noise
    detail_smooth = cv2.GaussianBlur(detail_raw, (0, 0), sigmaX=1.0)
    detail_clipped = np.clip(detail_smooth, -0.22, 0.22)

    # Mixed confidence mask
    dist = cv2.distanceTransform(fg_mask.astype(np.uint8) * 255, cv2.DIST_L2, 5)
    interior_px = max(6, int(min(h, w) * 0.025))
    interior_weight = np.clip(dist / interior_px, 0.0, 1.0).astype(np.float32)

    lum_for_grad = cv2.GaussianBlur(lum_norm, (0, 0), sigmaX=2.0)
    gx = cv2.Sobel(lum_for_grad, cv2.CV_32F, 1, 0, ksize=3)
    gy = cv2.Sobel(lum_for_grad, cv2.CV_32F, 0, 1, ksize=3)
    lum_grad = np.sqrt(gx ** 2 + gy ** 2)
    lg_max = lum_grad[fg_mask].max() if np.any(fg_mask) else 1.0
    if lg_max > 1e-6:
        lum_grad_norm = np.clip(lum_grad / lg_max, 0.0, 1.0)
    else:
        lum_grad_norm = np.zeros_like(lum_grad)

    confidence = 0.65 * interior_weight + 0.35 * lum_grad_norm
    confidence[~fg_mask] = 0.0

    save_debug("08b_detail_confidence", confidence, cfg)

    # Apply detail to depth — boosted inside face regions
    if face_mask is not None and np.any(face_mask > 0.1):
        # face_mask=0 → base strength, face_mask=1 → strength * 1.5
        per_pixel_strength = strength * (1.0 + face_mask * 0.5)
        detail_applied = detail_clipped * confidence * per_pixel_strength
    else:
        detail_applied = detail_clipped * confidence * strength
    out[fg_mask] = np.clip(out[fg_mask] + detail_applied[fg_mask], 0.0, 1.0)

    # Final light bilateral
    out = cv2.bilateralFilter(
        out.astype(np.float32),
        d=cfg.llm_relief_final_bilateral_d,
        sigmaColor=cfg.llm_relief_final_bilateral_sigma_color,
        sigmaSpace=cfg.llm_relief_final_bilateral_sigma_space,
    )
    out[~fg_mask] = 0.0
    return out


def _contrast(depth: np.ndarray, fg_mask: np.ndarray) -> np.ndarray:
    """Gentle S-curve contrast adjustment."""
    out = depth.copy()
    if not np.any(fg_mask):
        return out
    vals = out[fg_mask]
    mean_v = float(np.mean(vals))
    centered = vals - mean_v
    expanded = mean_v + centered * 1.15
    out[fg_mask] = np.clip(expanded, 0.0, 1.0)
    out[~fg_mask] = 0.0
    return out


def _feather(depth: np.ndarray, fg_mask: np.ndarray,
             feather_pct: float = 0.005) -> np.ndarray:
    """Soft silhouette feather near edges only."""
    dist = cv2.distanceTransform(fg_mask.astype(np.uint8) * 255, cv2.DIST_L2, 5)
    feather_px = max(1, int(min(depth.shape) * feather_pct))
    feather = np.clip(dist / feather_px, 0.0, 1.0).astype(np.float32)
    feather = np.power(feather, 0.5)
    out = depth * feather
    out[~fg_mask] = 0.0
    return out


def _heightmap(depth: np.ndarray, fg_mask: np.ndarray,
               cfg: Config) -> np.ndarray:
    """Print heightmap: maps depth to physical mm, applies edge bevel."""
    out = depth.copy().astype(np.float32)
    if not np.any(fg_mask):
        return out

    height_mm = np.zeros_like(out)
    height_mm[fg_mask] = cfg.base_height_mm + out[fg_mask] * cfg.relief_height_mm
    max_mm = cfg.base_height_mm + cfg.relief_height_mm

    if cfg.height_gamma != 1.0:
        height_mm[fg_mask] = max_mm * np.power(
            height_mm[fg_mask] / max_mm, cfg.height_gamma)

    heightmap = np.zeros_like(out)
    heightmap[fg_mask] = height_mm[fg_mask] / max_mm

    if cfg.edge_bevel_px > 0:
        dist = cv2.distanceTransform(fg_mask.astype(np.uint8) * 255, cv2.DIST_L2, 5)
        edge_pixels = fg_mask & (dist < cfg.edge_bevel_px)
        edge_mean = float(np.mean(heightmap[edge_pixels])) if np.any(edge_pixels) else 1.0
        if edge_mean > 0.15:
            bevel = np.clip(dist / cfg.edge_bevel_px, 0.0, 1.0).astype(np.float32)
            bevel = np.power(bevel, 0.6)
            heightmap[fg_mask] = heightmap[fg_mask] * bevel[fg_mask]

    heightmap[~fg_mask] = 0.0
    return np.clip(heightmap, 0.0, 1.0)


def _diagnostics(depth: np.ndarray, fg_mask: np.ndarray) -> None:
    """Print quality diagnostics and warnings."""
    if not np.any(fg_mask):
        print("  [WARNING] Empty foreground mask!")
        return

    vals = depth[fg_mask]
    log_depth_stats("final", depth, fg_mask)

    h = depth.shape[0]
    upper_mask = fg_mask.copy()
    upper_mask[h // 2:, :] = False
    lower_mask = fg_mask.copy()
    lower_mask[:h // 2, :] = False
    if np.any(upper_mask) and np.any(lower_mask):
        diff = abs(float(np.mean(depth[upper_mask])) - float(np.mean(depth[lower_mask])))
        if diff > 0.15:
            print(f"  [WARNING] Possible horizontal seam: diff={diff:.4f}")

    f32 = depth.astype(np.float32)
    smooth = cv2.GaussianBlur(f32, (0, 0), sigmaX=2)
    hf_energy = float(np.mean(np.abs(f32[fg_mask] - smooth[fg_mask])))
    if hf_energy > 0.02:
        print(f"  [WARNING] High-frequency noise: energy={hf_energy:.4f}")

    print(f"  [INFO] Unique depth levels (4dp): {len(np.unique(np.round(vals, 4)))}")


# ---------------------------------------------------------------------
# Main pipeline
# ---------------------------------------------------------------------

def estimate_depth(img_path: str, cfg: Config,
                   stage_callback=None) -> tuple[np.ndarray, int, int]:
    """LLM Relief depth pipeline.

    Depth Anything V2 → normalize → border halo suppression → smooth
    → detail recovery → contour suppression → contrast → feather
    → print heightmap.
    """
    def _stage(msg: str):
        print(msg)
        if stage_callback:
            stage_callback(msg)

    timer = Timer()
    raw = load_image(img_path)
    orig_h, orig_w = raw.shape[:2]

    raw_resized, _ = resize_for_inference(raw, cfg.inference_max_side)
    h, w = raw_resized.shape[:2]
    print(f"[LLM Relief] Resolution: {w}x{h} (original: {orig_w}x{orig_h})")
    save_debug("01_input", raw_resized, cfg)
    timer.log("image load + resize")

    # 1. Foreground mask
    _stage("Computing foreground mask...")
    if cfg.remove_bg:
        fg_mask = get_fg_mask(img_path, (h, w))
    else:
        fg_mask = np.ones((h, w), dtype=bool)
    save_debug("02_foreground_mask", fg_mask, cfg)
    timer.log("foreground mask")

    # 2. Depth Anything V2
    _stage("Running Depth Anything V2...")
    depth = infer_depth_anything(raw_resized, max_side=cfg.inference_max_side)
    if depth.shape[:2] != (h, w):
        depth = cv2.resize(depth.astype(np.float32), (w, h),
                           interpolation=cv2.INTER_CUBIC)
    save_debug("03_raw_depth", depth, cfg)
    log_depth_stats("raw_depth", depth, fg_mask)
    timer.log("Depth Anything V2")

    # 2b. Face detection
    _stage("Detecting faces...")
    face_boxes = detect_faces(raw_resized, (h, w))
    face_mask = build_face_mask(face_boxes, (h, w))
    face_mask[~fg_mask] = 0.0
    if np.any(face_mask > 0.1):
        save_debug("03b_face_mask", face_mask, cfg)
        print(f"  [Faces] {len(face_boxes)} face(s) detected, mask covers "
              f"{(face_mask > 0.1).sum() / fg_mask.sum() * 100:.1f}% of foreground")
    else:
        print(f"  [Faces] No faces detected — using fallback heuristics")
        face_mask = None
    timer.log("face detection")

    # 3. Normalize
    _stage("Normalizing depth...")
    depth[~fg_mask] = 0.0
    depth = _normalize(depth, fg_mask)
    save_debug("04_normalized", depth, cfg)
    log_depth_stats("normalized", depth, fg_mask)
    timer.log("normalization")

    # 4. Border halo suppression
    depth = _suppress_border_halo(depth, fg_mask, cfg)
    timer.log("border halo")

    # 4b. Face/cloth rebalance
    depth = _rebalance_face_cloth(depth, fg_mask, cfg, face_mask=face_mask)
    timer.log("face/cloth rebalance")

    # 5. Smoothing
    _stage("Smoothing depth...")
    depth = _smooth(depth, fg_mask, face_mask=face_mask)
    save_debug("05_smoothed", depth, cfg)
    log_depth_stats("smoothed", depth, fg_mask)
    timer.log("smoothing")

    # 6. Detail recovery
    if cfg.llm_relief_detail_strength > 0:
        _stage("Recovering sculptural detail...")

        pre_std = float(np.std(depth[fg_mask])) if np.any(fg_mask) else 0.0
        pre_smooth = cv2.GaussianBlur(depth.astype(np.float32), (0, 0), sigmaX=2)
        pre_hf = float(np.mean(np.abs(depth[fg_mask] - pre_smooth[fg_mask]))) if np.any(fg_mask) else 0.0
        print(f"  Pre-detail: std={pre_std:.4f}, HF={pre_hf:.5f}, "
              f"mode={cfg.llm_relief_detail_mode}, strength={cfg.llm_relief_detail_strength:.2f}")

        # Debug: save detail layer visualization
        if cfg.save_debug:
            gray_dbg = cv2.cvtColor(raw_resized, cv2.COLOR_BGR2GRAY).astype(np.float32) / 255.0
            if gray_dbg.shape[:2] != (h, w):
                gray_dbg = cv2.resize(gray_dbg, (w, h), interpolation=cv2.INTER_LINEAR)
            fg_gray_dbg = gray_dbg[fg_mask]
            if fg_gray_dbg.size > 0:
                gp2, gp98 = np.percentile(fg_gray_dbg, (2, 98))
                grng = gp98 - gp2
                if grng > 1e-6:
                    lum_dbg = np.zeros_like(gray_dbg)
                    lum_dbg[fg_mask] = np.clip((gray_dbg[fg_mask] - gp2) / (grng + 1e-8), 0.0, 1.0)
                    sigma_s = 2.0 if cfg.llm_relief_detail_mode == "sculpt" else cfg.llm_relief_detail_blur_sigma
                    sigma_l = 24.0 if cfg.llm_relief_detail_mode == "sculpt" else cfg.llm_relief_detail_blur_sigma * 3.0
                    lum_s = cv2.GaussianBlur(lum_dbg, (0, 0), sigmaX=sigma_s)
                    lum_l = cv2.GaussianBlur(lum_dbg, (0, 0), sigmaX=sigma_l)
                    detail_vis = np.clip((lum_s - lum_l) * 5.0 + 0.5, 0.0, 1.0)
                    save_debug("06_detail_layer", detail_vis, cfg)

        depth = _detail_recovery(depth, raw_resized, fg_mask, cfg, face_mask=face_mask)
        save_debug("07_detail_recovered", depth, cfg)

        post_std = float(np.std(depth[fg_mask])) if np.any(fg_mask) else 0.0
        post_smooth = cv2.GaussianBlur(depth.astype(np.float32), (0, 0), sigmaX=2)
        post_hf = float(np.mean(np.abs(depth[fg_mask] - post_smooth[fg_mask]))) if np.any(fg_mask) else 0.0
        print(f"  Post-detail: std={post_std:.4f}, HF={post_hf:.5f}")
        print(f"  Delta: std={post_std - pre_std:+.4f}, HF={post_hf - pre_hf:+.5f}")

        log_depth_stats("detail_recovered", depth, fg_mask)
        timer.log("detail recovery")

    # 7. Contour suppression
    if cfg.llm_relief_contour_suppress:
        _stage("Suppressing contour artifacts...")
        depth = suppress_contours(depth, fg_mask, cfg.llm_relief_contour_strength)
        save_debug("08_contour_suppressed", depth, cfg)
        log_depth_stats("contour_suppressed", depth, fg_mask)
        timer.log("contour suppression")

    # 8. Contrast
    _stage("Adjusting contrast...")
    depth = _contrast(depth, fg_mask)
    log_depth_stats("contrast", depth, fg_mask)
    timer.log("contrast")

    # 9. Feather
    _stage("Feathering silhouette...")
    depth = _feather(depth, fg_mask, feather_pct=cfg.feather_pct)
    timer.log("feathering")

    # 10. Print heightmap
    if cfg.use_print_heightmap:
        _stage("Building print heightmap...")
        depth = _heightmap(depth, fg_mask, cfg)
        timer.log("print heightmap")

    # 11. Final cleanup
    depth[~fg_mask] = 0.0
    depth = np.clip(depth, 0.0, 1.0)

    save_debug("09_final_heightmap", depth, cfg)
    log_depth_stats("final_heightmap", depth, fg_mask)

    if cfg.save_debug:
        shaded = make_shaded_preview(depth, fg_mask)
        save_debug("10_shaded_preview", shaded, cfg)

    _diagnostics(depth, fg_mask)

    print(f"  [Total pipeline] {timer.total():.2f}s")
    return np.clip(depth, 0.0, 1.0), orig_w, orig_h


# ---------------------------------------------------------------------
# Export
# ---------------------------------------------------------------------

def save_depth_16bit(depth: np.ndarray, path: str,
                     orig_w: int = 0, orig_h: int = 0) -> None:
    """Write heightmap as 16-bit PNG."""
    d = depth.astype(np.float32)
    if orig_w > 0 and orig_h > 0 and d.shape[:2] != (orig_h, orig_w):
        d = cv2.resize(d, (orig_w, orig_h), interpolation=cv2.INTER_LINEAR)
    d = np.nan_to_num(d, nan=0.0, posinf=1.0, neginf=0.0)
    d = np.clip(d, 0.0, 1.0)
    depth_u16 = np.round(d * 65535.0).astype(np.uint16)
    ok = cv2.imwrite(str(path), depth_u16)
    if not ok:
        raise RuntimeError(f"Failed to write 16-bit depth PNG: {path}")


def save_depth_preview_8bit(depth: np.ndarray, path: str,
                            orig_w: int, orig_h: int) -> None:
    """Save an 8-bit visual preview with percentile normalization + gamma."""
    d = depth.astype(np.float32)
    if d.shape[:2] != (orig_h, orig_w):
        d = cv2.resize(d, (orig_w, orig_h), interpolation=cv2.INTER_LINEAR)
    d = np.nan_to_num(d, nan=0.0, posinf=1.0, neginf=0.0)
    d = np.clip(d, 0.0, 1.0)
    fg = d > 0.01
    preview = make_visual_preview(d, fg, gamma=0.65)
    out8 = (preview * 255.0).round().astype(np.uint8)
    cv2.imwrite(path, out8)


def make_visual_preview(heightmap: np.ndarray, fg_mask: np.ndarray,
                        gamma: float = 0.65) -> np.ndarray:
    """Contrast-normalized visual preview from a heightmap."""
    preview = np.zeros_like(heightmap, dtype=np.float32)
    vals = heightmap[fg_mask]
    if vals.size == 0:
        return preview
    p1, p99 = np.percentile(vals, (1, 99))
    norm = np.clip((heightmap[fg_mask] - p1) / (p99 - p1 + 1e-6), 0.0, 1.0)
    preview[fg_mask] = np.power(norm, gamma)
    return preview


def make_shaded_preview(heightmap: np.ndarray, fg_mask: np.ndarray) -> np.ndarray:
    """Lighting-based shaded preview for 3D depth perception."""
    h = heightmap.astype(np.float32)
    gx = cv2.Sobel(h, cv2.CV_32F, 1, 0, ksize=3)
    gy = cv2.Sobel(h, cv2.CV_32F, 0, 1, ksize=3)
    nx, ny = -gx, -gy
    nz = np.ones_like(h) * 0.6
    norm = np.sqrt(nx * nx + ny * ny + nz * nz) + 1e-6
    nx /= norm; ny /= norm; nz /= norm
    light = np.array([-0.4, -0.5, 0.8], dtype=np.float32)
    light /= np.linalg.norm(light)
    shaded = nx * light[0] + ny * light[1] + nz * light[2]
    shaded = np.clip(shaded, 0.0, 1.0)
    shaded[~fg_mask] = 0.0
    return shaded


def save_shaded_preview(depth: np.ndarray, path: str,
                        orig_w: int, orig_h: int) -> None:
    """Save an 8-bit shaded preview."""
    d = depth.astype(np.float32)
    if d.shape[:2] != (orig_h, orig_w):
        d = cv2.resize(d, (orig_w, orig_h), interpolation=cv2.INTER_LINEAR)
    d = np.nan_to_num(d, nan=0.0, posinf=1.0, neginf=0.0)
    d = np.clip(d, 0.0, 1.0)
    fg = d > 0.01
    shaded = make_shaded_preview(d, fg)
    out8 = (shaded * 255.0).round().astype(np.uint8)
    cv2.imwrite(path, out8)


# ---------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------

def parse_args():
    p = argparse.ArgumentParser(description="Generate 16-bit depth maps for FDM bas-relief")
    p.add_argument("input", help="Input image path")
    p.add_argument("-o", "--output", help="Output path (default: <input>_depth.png)")
    p.add_argument("--mode", default="final_quality",
                   choices=["fast_preview", "balanced", "final_quality"])
    p.add_argument("--remove-bg", action="store_true", help="Use foreground mask")
    p.add_argument("--print-mode", action="store_true",
                   help="Enable print heightmap conversion")
    p.add_argument("--gamma", type=float, default=None)
    p.add_argument("--save-debug", action="store_true")
    p.add_argument("--debug-dir", default="debug_depth")
    p.add_argument("--detail-strength", type=float, default=None,
                   help="Detail recovery strength (default: 0.40)")
    p.add_argument("--detail-mode", default=None, choices=["safe", "sculpt"],
                   help="Detail recovery mode (default: sculpt)")
    p.add_argument("--no-contour-suppress", action="store_true",
                   help="Disable contour suppression")
    p.add_argument("--no-print-heightmap", action="store_true",
                   help="Disable print heightmap conversion")
    return p.parse_args()


def main():
    args = parse_args()
    t0 = time.time()

    input_path = Path(args.input)
    if not input_path.exists():
        raise FileNotFoundError(f"Input image not found: {input_path}")

    output_path = (Path(args.output) if args.output
                   else input_path.with_name(f"{input_path.stem}_depth.png"))

    cfg = Config(
        mode=RunMode(args.mode),
        remove_bg=args.remove_bg,
        print_mode=args.print_mode,
        gamma=args.gamma,
        save_debug=args.save_debug,
        debug_dir=args.debug_dir,
        use_print_heightmap=not args.no_print_heightmap,
        llm_relief_contour_suppress=not args.no_contour_suppress,
    )
    cfg.apply_mode_defaults()

    if args.detail_strength is not None:
        cfg.llm_relief_detail_strength = args.detail_strength
    if args.detail_mode is not None:
        cfg.llm_relief_detail_mode = args.detail_mode

    depth, w, h = estimate_depth(str(input_path), cfg)

    t_save = time.time()
    save_depth_16bit(depth, str(output_path), w, h)

    preview_path = output_path.with_name(f"{output_path.stem}_preview.png")
    save_depth_preview_8bit(depth, str(preview_path), w, h)

    shaded_path = output_path.with_name(f"{output_path.stem}_shaded.png")
    save_shaded_preview(depth, str(shaded_path), w, h)

    print(f"  [export] {time.time() - t_save:.2f}s")
    print(f"Saved 16-bit: {output_path}")
    print(f"Saved preview: {preview_path}")
    print(f"Saved shaded: {shaded_path}")
    print(f"Done in {time.time() - t0:.1f}s")


if __name__ == "__main__":
    main()
