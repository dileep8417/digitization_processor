"""Depth Anything V2 inference wrapper."""

from __future__ import annotations

import os
import ssl
import sys
from pathlib import Path

import cv2
import numpy as np
import torch

REPO_PATH = Path.home() / ".cache/torch/hub/DepthAnything_Depth-Anything-V2_main"

MODEL_CONFIG = {"encoder": "vitb", "features": 128, "out_channels": [96, 192, 384, 768]}

WEIGHT_URL = (
    "https://huggingface.co/depth-anything/Depth-Anything-V2-Base"
    "/resolve/main/depth_anything_v2_vitb.pth"
)

_model = None
_device = None


def _get_device() -> str:
    if torch.cuda.is_available():
        return "cuda"
    if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
        return "mps"
    return "cpu"


def _load_model() -> tuple:
    global _model, _device

    if _model is not None:
        return _model, _device

    # Workaround for corporate VPN/proxy SSL issues
    _orig_ctx = ssl._create_default_https_context
    try:
        ssl._create_default_https_context = ssl._create_unverified_context
    except AttributeError:
        pass

    try:
        # Download repo if needed
        if not REPO_PATH.exists():
            print("Downloading Depth Anything V2 repo...")
            torch.hub.load(
                "DepthAnything/Depth-Anything-V2", "_",
                source="github", trust_repo=True, skip_validation=True,
            )

        sys.path.insert(0, str(REPO_PATH))
        from depth_anything_v2.dpt import DepthAnythingV2

        model = DepthAnythingV2(**MODEL_CONFIG)

        weights_dir = REPO_PATH / "checkpoints"
        weights_dir.mkdir(exist_ok=True)
        weights_path = weights_dir / "depth_anything_v2_vitb.pth"

        if not weights_path.exists():
            print("Downloading vitb weights (~350MB)...")
            torch.hub.download_url_to_file(WEIGHT_URL, str(weights_path))

        model.load_state_dict(torch.load(str(weights_path), map_location="cpu"))
        _device = _get_device()
        _model = model.to(_device).eval()
        print(f"Depth Anything V2 loaded on {_device}")
    finally:
        # Restore original SSL context
        ssl._create_default_https_context = _orig_ctx

    return _model, _device


def infer_depth_anything(image: np.ndarray, max_side: int = 768) -> np.ndarray:
    """Run Depth Anything V2 inference.

    Args:
        image: BGR uint8 image (from cv2.imread)
        max_side: resize longest side before inference

    Returns:
        float32 depth map (H, W) normalized 0-1, near=high
    """
    model, device = _load_model()

    # Resize preserving aspect ratio
    h, w = image.shape[:2]
    if max(h, w) > max_side:
        scale = max_side / max(h, w)
        image = cv2.resize(image, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_AREA)

    depth = model.infer_image(image, input_size=518)
    depth = depth.astype(np.float32)

    # Normalize to 0-1
    d_min, d_max = depth.min(), depth.max()
    if d_max - d_min > 1e-8:
        depth = (depth - d_min) / (d_max - d_min)
    else:
        depth = np.zeros_like(depth)

    return depth
