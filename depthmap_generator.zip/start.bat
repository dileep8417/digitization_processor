@echo off
REM Depth Map Generator — Windows startup script
REM Double-click this file to start the application

cd /d "%~dp0"

echo ===================================
echo   Depth Map Generator
echo ===================================
echo.

REM Check Python — prefer python3, fall back to python
where python3 >nul 2>&1
if %errorlevel% equ 0 (
    set PYTHON=python3
    set PIP=pip3
) else (
    where python >nul 2>&1
    if %errorlevel% equ 0 (
        set PYTHON=python
        set PIP=pip
    ) else (
        echo ERROR: Python not found. Install Python 3.10+ from https://python.org
        echo Make sure to check "Add Python to PATH" during installation.
        pause
        exit /b 1
    )
)

for /f "tokens=*" %%i in ('%PYTHON% --version') do echo Using: %%i

REM Create virtual environment if not present
if not exist ".venv" (
    echo.
    echo Creating virtual environment...
    %PYTHON% -m venv .venv
)

REM Activate virtual environment
call .venv\Scripts\activate.bat

REM Install/update dependencies
echo.
echo Checking dependencies...
%PIP% install --quiet --upgrade pip
%PIP% install --quiet -r requirements.txt

REM Start the application
echo.
echo Starting server...
echo Open http://localhost:5000 in your browser
echo.
%PYTHON% app.py

pause
