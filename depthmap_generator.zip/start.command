#!/bin/bash
# Depth Map Generator — macOS/Linux startup script
# Double-click this file on macOS to start the application

cd "$(dirname "$0")"

echo "==================================="
echo "  Depth Map Generator"
echo "==================================="
echo ""

# Check Python
if command -v python3 &>/dev/null; then
    PYTHON=python3
    PIP=pip3
elif command -v python &>/dev/null; then
    PYTHON=python
    PIP=pip
else
    echo "ERROR: Python not found. Install Python 3.10+ from https://python.org"
    echo "Press Enter to exit..."
    read
    exit 1
fi

echo "Using: $($PYTHON --version)"

# Create virtual environment if not present
if [ ! -d ".venv" ]; then
    echo ""
    echo "Creating virtual environment..."
    $PYTHON -m venv .venv
fi

# Activate virtual environment
source .venv/bin/activate

# Install/update dependencies
echo ""
echo "Checking dependencies..."
$PIP install --quiet --upgrade pip
$PIP install --quiet -r requirements.txt

# Start the application
echo ""
echo "Starting server..."
echo "Open http://localhost:5000 in your browser"
echo ""
$PYTHON app.py
