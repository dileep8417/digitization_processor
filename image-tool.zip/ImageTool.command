#!/bin/bash
cd "$(dirname "$0")"

PYTHON=$(command -v python3 || command -v python)
if [ -z "$PYTHON" ]; then
    echo "Error: Python is not installed. Please install Python 3 and try again."
    read -p "Press Enter to exit..."
    exit 1
fi

if [ ! -d "venv" ]; then
    echo "Setting up virtual environment..."
    "$PYTHON" -m venv venv
    if [ $? -ne 0 ]; then
        echo "Error: Failed to create virtual environment."
        read -p "Press Enter to exit..."
        exit 1
    fi
fi

VENV_PYTHON="./venv/bin/python3"

if [ ! -f "venv/.deps_installed" ]; then
    echo "Installing dependencies..."
    "$VENV_PYTHON" -m pip install -q -r requirements.txt
    if [ $? -ne 0 ]; then
        echo "Error: Failed to install dependencies."
        read -p "Press Enter to exit..."
        exit 1
    fi
    touch venv/.deps_installed
fi

"$VENV_PYTHON" launcher.py
