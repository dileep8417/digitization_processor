# 🛠️ Image Tool

A suite of image processing tools for portrait preprocessing, embroidery digitizing, and LLM prompt management.

- **Image Enhancer** — Improve photo quality (crop, denoise, contrast) before sending to an LLM for cartoon generation
- **Embroidery Preprocessor** — Convert cartoon-style portraits into embroidery-ready images for auto-digitizing tools (e.g., Wilcom)
- **Prompt Manager** — Save, organize, and copy LLM prompts

![Python](https://img.shields.io/badge/Python-3.10%2B-blue)

## Project Structure

```
embroidery_preprocess/
├── pipeline.py                       # Embroidery image processing pipeline
├── enhancer.py                       # Photo enhancer for LLM preprocessing
├── app.py                            # Flask web frontend
├── launcher.py                       # Cross-platform auto-launch script
├── requirements.txt                  # Python dependencies
├── ImageProcessor.command            # macOS double-click launcher
├── ImageProcessor.bat                # Windows double-click launcher
├── prompts.json                      # Saved LLM prompts (auto-created)
├── templates/
│   ├── home.html                     # Tool selection page
│   ├── enhancer.html                 # Image enhancer UI
│   ├── embroidery.html               # Embroidery preprocessor UI
│   └── prompts.html                  # Prompt manager UI
├── images/                           # Input images (place your files here)
└── generated/                        # Output images (created automatically)
```

## Setup

### 1. Clone the repository

```bash
git clone <your-repo-url>
cd embroidery_preprocess
```

### 2. Create a virtual environment

```bash
python3 -m venv venv
source venv/bin/activate        # macOS/Linux
# venv\Scripts\activate          # Windows
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

## Usage

### Web UI (recommended)

```bash
source venv/bin/activate
python app.py
```

Open **http://localhost:5001** in your browser.

1. Upload a cartoon-style portrait (PNG/JPEG)
2. (Optional) Expand **Advanced Settings** to tweak parameters or toggle pipeline stages — hover over the **?** icon for guidance
3. Click **Process Image**
4. Preview the result and click **Download Result** to save

### Quick Launch (Double-Click to Run)

Instead of using the terminal, double-click a shortcut to start the app and open the browser automatically:

- **macOS** — double-click `ImageProcessor.command`
- **Windows** — double-click `ImageProcessor.bat`

> On macOS, if you get a "not identified developer" warning, right-click → Open → Open. You only need to do this once.

> On Windows, to add a custom icon: right-click `ImageProcessor.bat` → Create shortcut → right-click the shortcut → Properties → Change Icon → browse to any `.ico` file.

To stop the server, close the terminal window or press `Ctrl+C`.

### Command Line

```bash
# Basic usage (reads from images/ folder, saves to generated/)
python pipeline.py <image_name>

# Examples
python pipeline.py yovan                          # looks up images/yovan.png
python pipeline.py couple.jpg                     # looks up images/couple.jpg
python pipeline.py /path/to/photo.png             # absolute path

# With options
python pipeline.py yovan -K 8 -w 768              # 8 fill colors, 768px wide
python pipeline.py yovan --dark-threshold 100      # detect more outlines
python pipeline.py yovan --no-remove-bg            # skip background removal
python pipeline.py yovan -o output.png             # custom output path
python pipeline.py yovan --debug                   # save intermediate stages to debug_output/
```

### CLI Options

| Flag | Default | Description |
|------|---------|-------------|
| `-K` | 6 | Number of fill colors |
| `-w`, `--width` | 512 | Resize width in pixels |
| `--dark-threshold` | 80 | Outline detection sensitivity (0–255) |
| `--white-threshold` | 200 | White highlight detection (0–255) |
| `--no-remove-bg` | — | Skip background removal |
| `-o`, `--output` | auto | Custom output file path |
| `--bg-only` | — | Background removal only — no stylization |
| `--debug` | — | Save intermediate pipeline stages |
| `--debug-dir` | `debug_output` | Directory for debug output |

## Advanced Settings Reference

### Sliders

| Setting | Default | ↑ Increase | ↓ Decrease |
|---------|---------|------------|------------|
| **Resize Width** | 512 | Sharper, more detailed output | Faster processing, smaller files |
| **Fill Colors** | 6 | More subtle details (blush, shadows) | Simpler, bolder look |
| **Smoothing Strength** | 3 | Cleaner color patches, less noise | More original texture preserved |
| **Color Blending** | 30 | Similar shades merge together | Subtle color differences kept |
| **Blend Reach** | 30 | Broader, more uniform areas | Blending stays local |
| **Gap Filling** | 3 | Fills more gaps in color regions | Preserves thin lines |
| **Outline Sensitivity** | 80 | Detects fainter lines (may catch shadows) | Only the darkest outlines |
| **White Detection** | 200 | Only the brightest whites detected | Includes slightly off-white areas |
| **BG Removal Strictness** | 128 | Removes more aggressively (may clip edges) | Keeps more edges (may leave remnants) |

### Pipeline Stage Toggles

Each processing stage can be individually enabled or disabled:

| Toggle | Default | What it does |
|--------|---------|-------------|
| **Outline Detection** | On | Detects and preserves black outlines |
| **White Highlight Detection** | On | Preserves teeth and eye whites |
| **Color Smoothing** | On | Smooths colors before quantization |
| **Color Quantization (K-Means)** | On | Reduces image to flat fill colors |
| **Noise Cleanup** | On | Removes tiny speckled regions |
| **Remove Background** | On | Removes background via edge flood-fill |

> **Tip:** To only remove the background without any color processing, disable all toggles except **Remove Background**.

## Standalone Background Removal

To remove the background from an image without any color processing:

```bash
python remove_bg.py <image_name>
```

## Troubleshooting

- **Result looks noisy** — Increase **Smoothing Strength** and **Color Blending**.
