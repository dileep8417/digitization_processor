"""Flask frontend for Image Processing Tools."""

import base64
import json
import os
import tempfile
import uuid

import cv2
import numpy as np
from flask import Flask, render_template, request, jsonify

from pipeline import process_image, DEFAULT_CONFIG
from enhancer import enhance_image, DEFAULT_ENHANCE_CONFIG

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 50 * 1024 * 1024  # 50 MB

# Prompts storage
_PROMPTS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "prompts.json")


def _load_prompts() -> list:
    if os.path.exists(_PROMPTS_FILE):
        with open(_PROMPTS_FILE, "r") as f:
            return json.load(f)
    return []


def _save_prompts(prompts: list) -> None:
    with open(_PROMPTS_FILE, "w") as f:
        json.dump(prompts, f, indent=2)

# Registry of tools — add new tools here
TOOLS = [
    {
        "id": "enhancer",
        "name": "Image Enhancer",
        "icon": "✨",
        "description": "Improve photo quality — auto-crop to faces, fix brightness, contrast, sharpness — before generating cartoon portraits.",
        "url": "/enhancer",
    },
    {
        "id": "embroidery",
        "name": "Embroidery Preprocessor",
        "icon": "🧵",
        "description": "Convert cartoon-style portraits into embroidery-ready images for auto-digitizing tools like Wilcom.",
        "url": "/embroidery",
    },
    {
        "id": "prompts",
        "name": "Prompt Manager",
        "icon": "📝",
        "description": "Save, organize, and copy LLM prompts for cartoon generation and embroidery preprocessing.",
        "url": "/prompts",
    },
]


@app.route("/")
def home():
    return render_template("home.html", tools=TOOLS)


@app.route("/embroidery")
def embroidery():
    return render_template("embroidery.html", defaults=DEFAULT_CONFIG)


@app.route("/embroidery/process", methods=["POST"])
def embroidery_process():
    file = request.files.get("image")
    if not file:
        return jsonify(error="No image uploaded"), 400

    file_bytes = np.frombuffer(file.read(), np.uint8)
    image = cv2.imdecode(file_bytes, cv2.IMREAD_COLOR)
    if image is None:
        return jsonify(error="Invalid image file"), 400

    cfg = {}
    for key, default in DEFAULT_CONFIG.items():
        val = request.form.get(key)
        if val is None:
            continue
        if isinstance(default, bool):
            cfg[key] = val.lower() in ("true", "1", "on")
        elif isinstance(default, int):
            cfg[key] = int(val)
        elif isinstance(default, float):
            cfg[key] = float(val)
        else:
            cfg[key] = val

    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp_in, \
         tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp_out:
        tmp_in_path, tmp_out_path = tmp_in.name, tmp_out.name
        cv2.imwrite(tmp_in_path, image)

    try:
        process_image(tmp_in_path, tmp_out_path, cfg)
    except Exception as e:
        return jsonify(error=str(e)), 500

    try:
        result = cv2.imread(tmp_out_path, cv2.IMREAD_UNCHANGED)
        _, buf = cv2.imencode(".png", result)
        b64 = base64.b64encode(buf).decode("utf-8")
        return jsonify(image=b64)
    except Exception as e:
        return jsonify(error=str(e)), 500
    finally:
        os.unlink(tmp_in_path)
        os.unlink(tmp_out_path)


@app.route("/enhancer")
def enhancer():
    return render_template("enhancer.html", defaults=DEFAULT_ENHANCE_CONFIG)


@app.route("/enhancer/process", methods=["POST"])
def enhancer_process():
    file = request.files.get("image")
    if not file:
        return jsonify(error="No image uploaded"), 400

    file_bytes = np.frombuffer(file.read(), np.uint8)
    image = cv2.imdecode(file_bytes, cv2.IMREAD_COLOR)
    if image is None:
        return jsonify(error="Invalid image file"), 400

    cfg = {}
    for key, default in DEFAULT_ENHANCE_CONFIG.items():
        val = request.form.get(key)
        if val is None:
            continue
        if isinstance(default, bool):
            cfg[key] = val.lower() in ("true", "1", "on")
        elif isinstance(default, int):
            cfg[key] = int(val)
        elif isinstance(default, float):
            cfg[key] = float(val)
        else:
            cfg[key] = val

    try:
        crop_box = None
        crop_json = request.form.get("crop_box")
        if crop_json:
            import json
            crop_box = json.loads(crop_json)

        result = enhance_image(image, cfg, crop_box=crop_box)
        _, buf = cv2.imencode(".png", result)
        b64 = base64.b64encode(buf).decode("utf-8")
        return jsonify(image=b64)
    except Exception as e:
        return jsonify(error=str(e)), 500


@app.route("/prompts")
def prompts_page():
    return render_template("prompts.html")


@app.route("/prompts/api", methods=["GET"])
def prompts_list():
    return jsonify(prompts=_load_prompts())


@app.route("/prompts/api", methods=["POST"])
def prompts_create():
    data = request.get_json()
    if not data or not data.get("title") or not data.get("prompt"):
        return jsonify(error="Title and prompt are required"), 400
    prompts = _load_prompts()
    entry = {"id": str(uuid.uuid4()), "title": data["title"].strip(), "prompt": data["prompt"].strip()}
    prompts.append(entry)
    _save_prompts(prompts)
    return jsonify(entry), 201


@app.route("/prompts/api/<prompt_id>", methods=["PUT"])
def prompts_update(prompt_id):
    data = request.get_json()
    if not data or not data.get("title") or not data.get("prompt"):
        return jsonify(error="Title and prompt are required"), 400
    prompts = _load_prompts()
    for p in prompts:
        if p["id"] == prompt_id:
            p["title"] = data["title"].strip()
            p["prompt"] = data["prompt"].strip()
            _save_prompts(prompts)
            return jsonify(p)
    return jsonify(error="Prompt not found"), 404


@app.route("/prompts/api/<prompt_id>", methods=["DELETE"])
def prompts_delete(prompt_id):
    prompts = _load_prompts()
    prompts = [p for p in prompts if p["id"] != prompt_id]
    _save_prompts(prompts)
    return jsonify(ok=True)


if __name__ == "__main__":
    app.run(debug=True, port=5001)
