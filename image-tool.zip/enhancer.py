"""
Image Enhancer
==============
Prepares photos for LLM cartoon generation by improving clarity,
cropping to faces, and adjusting brightness/contrast/sharpness.

Optimized for: identity preservation, facial readability,
reduced background distraction, natural skin tones.
"""

import cv2
import numpy as np

DEFAULT_ENHANCE_CONFIG = {
    "auto_enhance": True,
    "auto_crop": False,
    "crop_padding": 25,
    "brightness": 3,
    "contrast": 4,
    "sharpness": 6,
    "denoise": 4,
    "saturation": 4,
    "enable_subject_focus": True,
    # BG suppression: intentionally mild to reduce distraction without looking edited
    "background_blur": 13,
    "background_desaturation": 15,
    "enable_upscale": True,
    "target_min_width": 768,
}

# Haar cascade for face detection (ships with OpenCV)
_FACE_CASCADE = None


def _get_face_cascade():
    global _FACE_CASCADE
    if _FACE_CASCADE is None:
        cascade_path = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
        _FACE_CASCADE = cv2.CascadeClassifier(cascade_path)
    return _FACE_CASCADE


def detect_faces(image: np.ndarray) -> list:
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    cascade = _get_face_cascade()
    faces = cascade.detectMultiScale(
        gray,
        scaleFactor=1.05,
        minNeighbors=3,
        minSize=(20, 20)
    )
    return faces if len(faces) > 0 else []


def crop_to_faces(image: np.ndarray, padding_pct: int = 25) -> np.ndarray:
    faces = detect_faces(image)
    h, w = image.shape[:2]

    if len(faces) == 0:
        # fallback center portrait crop
        crop_w = int(w * 0.58)
        crop_h = int(h * 0.78)
        x1 = max(0, (w - crop_w) // 2)
        y1 = max(0, int(h * 0.12))
        x2 = min(w, x1 + crop_w)
        y2 = min(h, y1 + crop_h)
        return image[y1:y2, x1:x2]

    # --- Filter obvious false positives ---
    filtered = []
    img_cx, img_cy = w / 2, h / 2

    for (x, y, fw, fh) in faces:
        area = fw * fh
        area_ratio = area / float(w * h)

        # reject tiny detections
        if fw < 60 or fh < 60:
            continue

        # reject huge detections
        if area_ratio > 0.08:
            continue

        # prefer boxes nearer the center
        cx = x + fw / 2
        cy = y + fh / 2
        dist = ((cx - img_cx) ** 2 + (cy - img_cy) ** 2) ** 0.5

        filtered.append((x, y, fw, fh, area, dist))

    if len(filtered) == 0:
        # fallback center portrait crop
        crop_w = int(w * 0.58)
        crop_h = int(h * 0.78)
        x1 = max(0, (w - crop_w) // 2)
        y1 = max(0, int(h * 0.12))
        x2 = min(w, x1 + crop_w)
        y2 = min(h, y1 + crop_h)
        return image[y1:y2, x1:x2]

    # Sort by: larger area first, then nearer center
    filtered.sort(key=lambda f: (-f[4], f[5]))

    # Keep top 2 likely faces
    selected = filtered[:2]
    selected = [(x, y, fw, fh) for (x, y, fw, fh, _, _) in selected]

    x_min = min(f[0] for f in selected)
    y_min = min(f[1] for f in selected)
    x_max = max(f[0] + f[2] for f in selected)
    y_max = max(f[1] + f[3] for f in selected)

    face_h = y_max - y_min
    face_w = x_max - x_min

    pad_x = int(face_w * padding_pct / 100 * 1.0)
    pad_top = int(face_h * padding_pct / 100 * 1.8)
    pad_bottom = int(face_h * padding_pct / 100 * 2.6)

    x1 = max(0, x_min - pad_x)
    y1 = max(0, y_min - pad_top)
    x2 = min(w, x_max + pad_x)
    y2 = min(h, y_max + pad_bottom)

    return image[y1:y2, x1:x2]

def crop_manual(image: np.ndarray, crop_box: dict) -> np.ndarray:
    """Apply manual crop from frontend coordinates. Overrides auto crop when provided."""
    h, w = image.shape[:2]

    x1 = max(0, min(w, crop_box["x1"]))
    y1 = max(0, min(h, crop_box["y1"]))
    x2 = max(0, min(w, crop_box["x2"]))
    y2 = max(0, min(h, crop_box["y2"]))

    # Safety: reject invalid or too-small crops
    if x2 - x1 < 200 or y2 - y1 < 200:
        return image

    return image[y1:y2, x1:x2]


def upscale_if_needed(image: np.ndarray, target_min_width: int = 768) -> np.ndarray:
    """Proportionally upscale small crops so facial features have enough pixels for LLM."""
    h, w = image.shape[:2]
    if w >= target_min_width:
        return image
    scale = target_min_width / w
    return cv2.resize(image, (target_min_width, int(h * scale)), interpolation=cv2.INTER_CUBIC)


def apply_subject_focus(image: np.ndarray, faces: list,
                        blur_strength: int = 15,
                        desaturation: int = 20) -> np.ndarray:
    """Suppress background and mildly de-emphasize non-face subject areas (clothing, jewelry)."""
    if len(faces) == 0 or (blur_strength <= 0 and desaturation <= 0):
        return image

    h, w = image.shape[:2]
    img_f = image.astype(np.float32)

    # Union box around all faces
    x_min = min(f[0] for f in faces)
    y_min = min(f[1] for f in faces)
    x_max = max(f[0] + f[2] for f in faces)
    y_max = max(f[1] + f[3] for f in faces)
    face_h = y_max - y_min
    face_w = x_max - x_min
    soft_k = max(face_h, face_w) | 1  # odd kernel for mask blurring

    # --- Face mask: high-priority, fully preserved ---
    face_mask = np.zeros((h, w), dtype=np.float32)
    for (fx, fy, fw, fh) in faces:
        # Slight expansion to include ears/hairline
        pad = int(fh * 0.15)
        fy1 = max(0, fy - pad)
        fy2 = min(h, fy + fh + pad)
        fx1 = max(0, fx - pad)
        fx2 = min(w, fx + fw + pad)
        face_mask[fy1:fy2, fx1:fx2] = 1.0
    face_mask = cv2.GaussianBlur(face_mask, (soft_k, soft_k), 0)
    face_mask = np.clip(face_mask, 0, 1)

    # --- Subject mask: includes upper body ---
    cx = (x_min + x_max) // 2
    subject_x1 = max(0, cx - int(face_w * 1.2))
    subject_x2 = min(w, cx + int(face_w * 1.2))
    subject_y1 = max(0, y_min - int(face_h * 0.6))
    subject_y2 = min(h, y_max + int(face_h * 1.8))
    subject_mask = np.zeros((h, w), dtype=np.float32)
    subject_mask[subject_y1:subject_y2, subject_x1:subject_x2] = 1.0
    subject_mask = cv2.GaussianBlur(subject_mask, (soft_k, soft_k), 0)
    subject_mask = np.clip(subject_mask, 0, 1)

    # --- Non-face subject zone: inside subject but outside face ---
    body_mask = np.clip(subject_mask - face_mask, 0, 1)

    # --- Background zone: outside subject ---
    bg_mask = 1.0 - subject_mask

    # Background version: blur + desaturate
    bg_ksize = blur_strength | 1
    bg_img = cv2.GaussianBlur(image, (bg_ksize, bg_ksize), 0)
    if desaturation > 0:
        hsv = cv2.cvtColor(bg_img, cv2.COLOR_BGR2HSV).astype(np.float32)
        hsv[:, :, 1] *= (1.0 - desaturation / 100.0)
        bg_img = cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2BGR)
    bg_f = bg_img.astype(np.float32)

    # Body version: very mild blur + slight desaturation (reduce jewelry/pattern distraction)
    body_ksize = max(5, blur_strength // 2) | 1
    body_img = cv2.GaussianBlur(image, (body_ksize, body_ksize), 0)
    hsv_body = cv2.cvtColor(body_img, cv2.COLOR_BGR2HSV).astype(np.float32)
    hsv_body[:, :, 1] *= 0.94  # ~6% desaturation
    body_img = cv2.cvtColor(hsv_body.astype(np.uint8), cv2.COLOR_HSV2BGR)
    body_f = body_img.astype(np.float32)

    # Composite: face (original) + body (mild suppress) + background (full suppress)
    result = (img_f * face_mask[:, :, np.newaxis] +
              body_f * body_mask[:, :, np.newaxis] +
              bg_f * bg_mask[:, :, np.newaxis])
    return result.astype(np.uint8)


def auto_enhance(image: np.ndarray, blend: float = 0.3) -> np.ndarray:
    """Gentle contrast boost — blend stretched L with original to preserve natural lighting."""
    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    l_min, l_max = np.percentile(l, (2, 98))
    if l_max - l_min > 0:
        l_stretched = np.clip((l.astype(np.float32) - l_min) / (l_max - l_min) * 255, 0, 255)
        l = np.clip(l.astype(np.float32) * (1.0 - blend) + l_stretched * blend, 0, 255).astype(np.uint8)
    lab = cv2.merge([l, a, b])
    return cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)


def enhance_lip_region(image: np.ndarray, faces: list,
                       sat_boost: float = 0.12, contrast_boost: float = 0.10) -> np.ndarray:
    """Subtly boost saturation and contrast in the lip region of each face."""
    if len(faces) == 0:
        return image

    h, w = image.shape[:2]
    mask = np.zeros((h, w), dtype=np.float32)

    for (fx, fy, fw, fh) in faces:
        # Lips sit in the lower 35–55% of the face box, middle 60% horizontally
        ly1 = fy + int(fh * 0.35)
        ly2 = fy + int(fh * 0.55)
        lx1 = fx + int(fw * 0.2)
        lx2 = fx + int(fw * 0.8)
        ly1, ly2 = max(0, ly1), min(h, ly2)
        lx1, lx2 = max(0, lx1), min(w, lx2)
        mask[ly1:ly2, lx1:lx2] = 1.0

    # Soft edges so enhancement blends naturally into surrounding skin
    mask = cv2.GaussianBlur(mask, (0, 0), max(faces[0][3] * 0.08, 3))
    mask_3ch = mask[:, :, np.newaxis]

    # Boosted version: slight saturation + contrast in HSV/LAB
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV).astype(np.float32)
    hsv[:, :, 1] = np.clip(hsv[:, :, 1] * (1.0 + sat_boost), 0, 255)
    sat_img = cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2BGR)

    lab = cv2.cvtColor(sat_img, cv2.COLOR_BGR2LAB).astype(np.float32)
    lab[:, :, 0] = np.clip(lab[:, :, 0] * (1.0 + contrast_boost), 0, 255)
    boosted = cv2.cvtColor(lab.astype(np.uint8), cv2.COLOR_LAB2BGR)

    result = image.astype(np.float32) * (1.0 - mask_3ch) + boosted.astype(np.float32) * mask_3ch
    return result.astype(np.uint8)


def subtle_clarity(image: np.ndarray, strength: float = 0.12) -> np.ndarray:
    """Very mild local contrast on L channel — enhances lip/eye/nose edges without sharpening."""
    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    l_f = l.astype(np.float32)
    blurred = cv2.GaussianBlur(l_f, (0, 0), 1.8)
    detail = l_f - blurred
    l = np.clip(l_f + detail * strength, 0, 255).astype(np.uint8)
    lab = cv2.merge([l, a, b])
    return cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)


def enhance_eye_clarity(image: np.ndarray, faces: list, amount: float = 0.22) -> np.ndarray:
    """Very subtle sharpening limited to the eye band of each face."""
    if len(faces) == 0:
        return image

    h, w = image.shape[:2]
    mask = np.zeros((h, w), dtype=np.float32)

    for (fx, fy, fw, fh) in faces:
        # Eyes sit in upper 30–50% of face box, middle 80% horizontally
        ey1 = max(0, fy + int(fh * 0.30))
        ey2 = min(h, fy + int(fh * 0.50))
        ex1 = max(0, fx + int(fw * 0.1))
        ex2 = min(w, fx + int(fw * 0.9))
        mask[ey1:ey2, ex1:ex2] = 1.0

    # Soft edges to avoid visible boundary
    mask = cv2.GaussianBlur(mask, (0, 0), max(faces[0][3] * 0.06, 2))
    mask_3ch = mask[:, :, np.newaxis]

    # Very light unsharp mask on L channel only
    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    l_f = l.astype(np.float32)
    blurred = cv2.GaussianBlur(l_f, (0, 0), 1.2)
    l_sharp = np.clip(l_f + (l_f - blurred) * amount, 0, 255).astype(np.uint8)
    sharpened = cv2.cvtColor(cv2.merge([l_sharp, a, b]), cv2.COLOR_LAB2BGR)

    result = image.astype(np.float32) * (1.0 - mask_3ch) + sharpened.astype(np.float32) * mask_3ch
    return result.astype(np.uint8)


def edge_aware_sharpen(image: np.ndarray, amount: float = 0.3, threshold: float = 0.08) -> np.ndarray:
    """Sharpen structural + mid-level facial edges while keeping skin smooth."""
    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    l_f = l.astype(np.float32)

    # Edge detection
    gx = cv2.Sobel(l_f, cv2.CV_32F, 1, 0, ksize=3)
    gy = cv2.Sobel(l_f, cv2.CV_32F, 0, 1, ksize=3)
    mag = np.sqrt(gx ** 2 + gy ** 2)

    mag_max = mag.max()
    if mag_max == 0:
        return image

    mask = mag / mag_max

    # Include mid-level edges (important fix)
    mask = np.clip((mask - threshold) / (1.0 - threshold), 0, 1)
    mask = np.power(mask, 0.7)

    # Smooth transitions
    mask = cv2.GaussianBlur(mask, (0, 0), 1.2)

    # Unsharp mask
    blurred = cv2.GaussianBlur(l_f, (0, 0), 1.5)
    l_sharp = np.clip(l_f + (l_f - blurred) * amount, 0, 255)

    # Blend
    l_out = (l_f * (1.0 - mask) + l_sharp * mask).astype(np.uint8)

    return cv2.cvtColor(cv2.merge([l_out, a, b]), cv2.COLOR_LAB2BGR)

def adjust_brightness_contrast(image: np.ndarray, brightness: int = 0, contrast: int = 0) -> np.ndarray:
    if brightness == 0 and contrast == 0:
        return image
    beta = brightness * 1.5
    alpha = 1.0 + (contrast / 100.0)
    return np.clip(image.astype(np.float32) * alpha + beta, 0, 255).astype(np.uint8)


def adjust_sharpness(image: np.ndarray, strength: int = 0) -> np.ndarray:
    if strength <= 0:
        return image
    amount = strength / 100.0 * 0.4  # capped low to avoid halos
    blurred = cv2.GaussianBlur(image, (0, 0), 2)
    return cv2.addWeighted(image, 1.0 + amount, blurred, -amount, 0)


def reduce_noise(image: np.ndarray, strength: int = 0) -> np.ndarray:
    if strength <= 0:
        return image
    h = max(2, int(strength / 20))  # weaker — preserve lip/nose/eyelid edges
    return cv2.fastNlMeansDenoisingColored(image, None, h, h, 7, 21)


def adjust_saturation(image: np.ndarray, amount: int = 0) -> np.ndarray:
    if amount == 0:
        return image
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV).astype(np.float32)
    hsv[:, :, 1] = np.clip(hsv[:, :, 1] * (1.0 + amount / 100.0), 0, 255)
    return cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2BGR)

def enhance_image(image: np.ndarray, config: dict | None = None, crop_box: dict | None = None) -> np.ndarray:
    cfg = {**DEFAULT_ENHANCE_CONFIG, **(config or {})}

    result = image.copy()
    print("INPUT SHAPE:", result.shape)

    # PRIORITY 1: manual crop from frontend
    if crop_box is not None:
        print("Manual crop applied:", crop_box)
        result = crop_manual(result, crop_box)
    # PRIORITY 2: auto crop (only if manual not provided)
    elif cfg["auto_crop"]:
        result = crop_to_faces(result, cfg["crop_padding"])

    print("AFTER CROP SHAPE:", result.shape)

    if cfg["enable_upscale"]:
        result = upscale_if_needed(result, cfg["target_min_width"])
        print("AFTER UPSCALE SHAPE:", result.shape)

    faces = detect_faces(result) if cfg["enable_subject_focus"] else []
    print("FACES AFTER CROP:", len(faces), faces)

    result = reduce_noise(result, cfg["denoise"])

    if cfg["auto_enhance"]:
        result = auto_enhance(result)

    result = subtle_clarity(result)

    if len(faces) > 0:
        result = enhance_lip_region(result, faces)

    if cfg["enable_subject_focus"] and len(faces) > 0:
        result = apply_subject_focus(result, faces,
                                     cfg["background_blur"],
                                     cfg["background_desaturation"])

    result = adjust_brightness_contrast(result, cfg["brightness"], cfg["contrast"])
    result = adjust_sharpness(result, cfg["sharpness"])

    if len(faces) > 0:
        result = enhance_eye_clarity(result, faces)

    result = adjust_saturation(result, cfg["saturation"])
    result = edge_aware_sharpen(result)

    print("FINAL SHAPE:", result.shape)
    return result