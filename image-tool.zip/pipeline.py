"""
Embroidery Preprocessing Pipeline
==================================
Converts LLM-generated cartoon-like portraits into embroidery-friendly images
suitable for auto-digitizing tools (e.g., Wilcom).

Design principle:
  - Outlines = structure (dark strokes, preserved exactly as black)
  - Whites = highlights (teeth, eye whites, preserved as pure white)
  - Colors = fill (quantized, cleaned, flattened)
  - Background removal via flood-fill edge detection

Dependencies: OpenCV (cv2), NumPy
"""

import os
import cv2
import numpy as np

# ---------------------------------------------------------------------------
# Default configuration
# ---------------------------------------------------------------------------
DEFAULT_CONFIG = {
    "width": 512,
    "K": 8,
    "bilateral_d": 3,
    "bilateral_sigma_color": 30,
    "bilateral_sigma_space": 30,
    "morph_kernel_size": 3,
    "dark_threshold": 80,
    "white_threshold": 200,
    "remove_bg": True,
    "bg_alpha_cutoff": 128,
    "enable_smoothing": True,
    "enable_quantization": True,
    "enable_cleanup": True,
    "enable_outlines": True,
    "enable_whites": True,
    "background_only_mode": True,
    "debug": False,
    "debug_dir": "debug_output",
    "bg_lab_tolerance": 30,
}

_RNG_SEED = 42


# ---------------------------------------------------------------------------
# Stage 1 – Resize
# ---------------------------------------------------------------------------
def resize_image(image: np.ndarray, width: int = 512) -> np.ndarray:
    h, w = image.shape[:2]
    scale = width / w
    return cv2.resize(image, (width, int(h * scale)), interpolation=cv2.INTER_AREA)


# ---------------------------------------------------------------------------
# Stage 2 – Extract outline mask
# ---------------------------------------------------------------------------
def extract_outline_mask(image: np.ndarray, dark_threshold: int = 80) -> np.ndarray:
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    return (gray < dark_threshold).astype(np.uint8) * 255


# ---------------------------------------------------------------------------
# Stage 3 – Extract white highlight mask (teeth, eye whites)
# ---------------------------------------------------------------------------
def extract_white_mask(image: np.ndarray, white_threshold: int = 200) -> np.ndarray:
    b, g, r = cv2.split(image)

    # Use threshold to control sensitivity
    min_val = max(white_threshold - 30, 100)
    bright = (
        (r > min_val) &
        (g > min_val - 10) &
        (b > min_val - 20)
    ).astype(np.uint8) * 255

    # remove very large regions so background / clothing don't get picked
    h, w = image.shape[:2]
    max_area = int(0.01 * h * w)

    num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(bright, connectivity=8)
    result = np.zeros((h, w), dtype=np.uint8)

    for lbl in range(1, num_labels):
        area = stats[lbl, cv2.CC_STAT_AREA]
        if area <= max_area:
            result[labels == lbl] = 255

    return result

def extract_light_region_mask(image: np.ndarray) -> np.ndarray:
    b, g, r = cv2.split(image)

    # detect very light regions like white clothing
    light_mask = (
        (r > 200) &
        (g > 200) &
        (b > 200)
    ).astype(np.uint8) * 255

    # smooth small gaps/noise
    kernel = np.ones((5, 5), np.uint8)
    light_mask = cv2.morphologyEx(light_mask, cv2.MORPH_CLOSE, kernel)
    light_mask = cv2.morphologyEx(light_mask, cv2.MORPH_OPEN, kernel)

    # keep only large components
    h, w = image.shape[:2]
    min_area = int(0.02 * h * w)

    num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(
        light_mask, connectivity=8
    )

    result = np.zeros((h, w), dtype=np.uint8)
    for lbl in range(1, num_labels):
        if stats[lbl, cv2.CC_STAT_AREA] >= min_area:
            result[labels == lbl] = 255

    return result

# ---------------------------------------------------------------------------
# Stage 4 – Build color layer
# ---------------------------------------------------------------------------
def build_color_layer(image: np.ndarray, protected_mask: np.ndarray) -> np.ndarray:
    return cv2.inpaint(image, protected_mask, inpaintRadius=5, flags=cv2.INPAINT_TELEA)


# ---------------------------------------------------------------------------
# Stage 5 – Bilateral filter
# ---------------------------------------------------------------------------
def apply_bilateral_filter(image: np.ndarray, d: int = 5,
                           sigma_color: int = 40, sigma_space: int = 40) -> np.ndarray:
    return cv2.bilateralFilter(image, d, sigma_color, sigma_space)


# ---------------------------------------------------------------------------
# Stage 6 – K-means color quantization
# ---------------------------------------------------------------------------
def kmeans_quantization(image: np.ndarray, K: int = 5,
                        fg_mask: np.ndarray | None = None) -> np.ndarray:
    """Quantize foreground in CIELAB space. Background pixels are left unchanged."""
    h, w, c = image.shape
    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
    all_pixels = lab.reshape(-1, 3).astype(np.float32)

    if fg_mask is not None:
        fg_flat = fg_mask.flatten() > 0
        cluster_pixels = all_pixels[fg_flat]
    else:
        fg_flat = None
        cluster_pixels = all_pixels

    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 20, 1.0)
    cv2.setRNGSeed(_RNG_SEED)
    _, labels, centers = cv2.kmeans(cluster_pixels, K, None, criteria, 10,
                                     cv2.KMEANS_PP_CENTERS)

    if fg_flat is not None:
        # Only recolor foreground pixels; background keeps original RGB
        result = image.copy()
        fg_indices = np.where(fg_flat)[0]
        quantized_fg = np.uint8(centers)[labels.flatten()]
        # Convert quantized LAB back to BGR
        fg_bgr = cv2.cvtColor(quantized_fg.reshape(1, -1, 3), cv2.COLOR_LAB2BGR).reshape(-1, 3)
        result_flat = result.reshape(-1, 3)
        result_flat[fg_indices] = fg_bgr
        return result_flat.reshape(h, w, 3)
    else:
        all_labels = labels.flatten()
        quantized_lab = np.uint8(centers)[all_labels].reshape(h, w, 3)
        return cv2.cvtColor(quantized_lab, cv2.COLOR_LAB2BGR)


# ---------------------------------------------------------------------------
# Stage 7 – Remove small noisy regions
# ---------------------------------------------------------------------------
def remove_small_regions(image: np.ndarray, min_area: int = 500,
                        fg_mask: np.ndarray | None = None) -> np.ndarray:
    """Replace tiny color blobs with their dominant neighbor.
    If fg_mask is provided, only process regions fully inside foreground."""
    h, w, c = image.shape
    flat = image.reshape(-1, c)
    color_ids = (flat[:, 0].astype(np.int32) * 65536 +
                 flat[:, 1].astype(np.int32) * 256 +
                 flat[:, 2].astype(np.int32))
    color_id_map = color_ids.reshape(h, w)
    result = image.copy()

    fg_binary = None
    if fg_mask is not None:
        fg_binary = fg_mask > 0

    for uid in np.unique(color_id_map):
        mask = np.uint8(color_id_map == uid) * 255
        num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
        for lbl in range(1, num_labels):
            if stats[lbl, cv2.CC_STAT_AREA] >= min_area:
                continue
            comp_mask = labels == lbl
            # Skip regions that touch background boundary
            if fg_binary is not None and not np.all(fg_binary[comp_mask]):
                continue
            dilated = cv2.dilate(comp_mask.astype(np.uint8) * 255,
                                 np.ones((5, 5), np.uint8), iterations=2)
            neighbor_mask = (dilated > 0) & ~comp_mask
            if not np.any(neighbor_mask):
                continue
            nc = result[neighbor_mask]
            nc_enc = (nc[:, 0].astype(np.int64) * 65536 +
                      nc[:, 1].astype(np.int64) * 256 +
                      nc[:, 2].astype(np.int64))
            values, counts = np.unique(nc_enc, return_counts=True)
            d = values[np.argmax(counts)]
            result[comp_mask] = np.array(
                [(d >> 16) & 0xFF, (d >> 8) & 0xFF, d & 0xFF], dtype=np.uint8
            )
    return result


# ---------------------------------------------------------------------------
# Stage 8 – Morphological closing
# ---------------------------------------------------------------------------
def apply_morphology(image: np.ndarray, kernel_size: int = 3) -> np.ndarray:
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (kernel_size, kernel_size))
    return cv2.morphologyEx(image, cv2.MORPH_CLOSE, kernel)


# ---------------------------------------------------------------------------
# Stage 9 – Merge near-duplicate colors
# ---------------------------------------------------------------------------
def merge_similar_colors(image: np.ndarray, min_distance: int = 12) -> np.ndarray:
    """Merge perceptually similar colors using LAB Delta-E distance,
    consistent with the LAB-space K-means quantization."""
    unique_bgr = np.unique(image.reshape(-1, 3), axis=0)
    if len(unique_bgr) <= 1:
        return image

    # Convert to LAB for perceptual comparison
    unique_bgr_3d = unique_bgr.reshape(1, -1, 3).astype(np.uint8)
    unique_lab = cv2.cvtColor(unique_bgr_3d, cv2.COLOR_BGR2LAB).reshape(-1, 3).astype(np.float32)

    merge_to = {}
    used = set()
    for i in range(len(unique_lab)):
        k1 = tuple(unique_bgr[i].astype(int))
        if k1 in used:
            continue
        used.add(k1)
        for j in range(i + 1, len(unique_lab)):
            k2 = tuple(unique_bgr[j].astype(int))
            if k2 in used:
                continue
            if np.linalg.norm(unique_lab[i] - unique_lab[j]) < min_distance:
                merge_to[k2] = k1
                used.add(k2)

    if not merge_to:
        return image
    result = image.copy()
    for src, dst in merge_to.items():
        mask = np.all(result == np.array(src, dtype=np.uint8), axis=2)
        result[mask] = np.array(dst, dtype=np.uint8)
    return result

def normalize_outline(mask: np.ndarray, thickness: int = 2) -> np.ndarray:
    kernel = np.ones((thickness, thickness), np.uint8)
    return cv2.dilate(mask, kernel, iterations=1)

# ---------------------------------------------------------------------------
# Stage 11 – Composite layers
# ---------------------------------------------------------------------------
def composite_final(color_layer: np.ndarray, outline_mask: np.ndarray,
                    white_mask: np.ndarray, white_pixels: np.ndarray) -> np.ndarray:
    result = color_layer.copy()
    result[white_mask > 0] = white_pixels[white_mask > 0]
    result[outline_mask > 0] = [0, 0, 0]
    return result


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def save_output(image: np.ndarray, path: str) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    cv2.imwrite(path, image, [cv2.IMWRITE_PNG_COMPRESSION, 0])


def _debug_save(image: np.ndarray, debug_dir: str, name: str) -> None:
    os.makedirs(debug_dir, exist_ok=True)
    cv2.imwrite(os.path.join(debug_dir, f"{name}.png"), image,
                [cv2.IMWRITE_PNG_COMPRESSION, 0])

# DEPRECATED: replaced by border-based estimate_border_bg_color + LAB distance.
# Kept for backward compatibility but no longer called by the pipeline.
def build_magenta_candidate_mask(
    image: np.ndarray,
    bg_color=(255, 0, 255),
    lab_tolerance: int = 35
) -> np.ndarray:
    # LAB closeness
    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB).astype(np.int16)
    bg_patch = np.zeros((1, 1, 3), dtype=np.uint8)
    bg_patch[0, 0] = np.array(bg_color, dtype=np.uint8)
    bg_lab = cv2.cvtColor(bg_patch, cv2.COLOR_BGR2LAB).astype(np.int16)[0, 0]
    dist = np.sqrt(np.sum((lab - bg_lab) ** 2, axis=2)).astype(np.float32)
    lab_mask = dist <= lab_tolerance

    # HSV magenta-like rule
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    h = hsv[:, :, 0]
    s = hsv[:, :, 1]
    v = hsv[:, :, 2]

    hsv_mask = (
        (h >= 140) & (h <= 170) &
        (s >= 80) &
        (v >= 80)
    )

    candidate = (lab_mask | hsv_mask).astype(np.uint8) * 255

    kernel = np.ones((3, 3), np.uint8)
    candidate = cv2.morphologyEx(candidate, cv2.MORPH_OPEN, kernel)
    candidate = cv2.morphologyEx(candidate, cv2.MORPH_CLOSE, kernel)
    candidate = cv2.dilate(candidate, kernel, iterations=1)

    return candidate

def extract_background_alpha(image: np.ndarray, alpha_cutoff: int = 128) -> np.ndarray:
    """Remove background using flood-fill from edges.
    Protects subject by detecting skin-tone and dark (outline) regions."""
    return extract_background_alpha_from_original(image)


def fill_holes(mask: np.ndarray) -> np.ndarray:
    h, w = mask.shape[:2]
    inv = cv2.bitwise_not(mask)
    flood = inv.copy()
    ff_mask = np.zeros((h + 2, w + 2), np.uint8)
    cv2.floodFill(flood, ff_mask, (0, 0), 128)
    holes = (flood == 255).astype(np.uint8) * 255
    return cv2.bitwise_or(mask, holes)


def estimate_border_bg_color(image: np.ndarray, quant_step: int = 16) -> np.ndarray:
    h, w = image.shape[:2]

    border_pixels = np.vstack([
        image[0, :, :],
        image[h - 1, :, :],
        image[:, 0, :],
        image[:, w - 1, :]
    ]).astype(np.int32)

    # Quantize to reduce tiny variations
    q = (border_pixels // quant_step) * quant_step

    encoded = q[:, 0] * 256 * 256 + q[:, 1] * 256 + q[:, 2]
    values, counts = np.unique(encoded, return_counts=True)
    dominant = values[np.argmax(counts)]

    b = (dominant // (256 * 256)) & 255
    g = (dominant // 256) & 255
    r = dominant & 255

    return np.array([b, g, r], dtype=np.uint8)


def extract_background_alpha_from_original(
    image: np.ndarray,
    lab_tolerance: int = 32
) -> np.ndarray:
    h, w = image.shape[:2]
    kernel = np.ones((3, 3), np.uint8)

    # 1. Detect dominant background color from border
    bg_color = estimate_border_bg_color(image)

    # 2. LAB similarity mask
    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB).astype(np.int16)

    bg_patch = np.zeros((1, 1, 3), dtype=np.uint8)
    bg_patch[0, 0] = bg_color
    bg_lab = cv2.cvtColor(bg_patch, cv2.COLOR_BGR2LAB).astype(np.int16)[0, 0]

    dist = np.sqrt(np.sum((lab - bg_lab) ** 2, axis=2)).astype(np.float32)
    candidate = (dist <= lab_tolerance).astype(np.uint8) * 255

    # 3. Clean candidate mask
    candidate = cv2.morphologyEx(candidate, cv2.MORPH_OPEN, kernel)
    candidate = cv2.morphologyEx(candidate, cv2.MORPH_CLOSE, kernel)

    # 4. Keep only border-connected candidate as real background
    flood = candidate.copy()

    for x in range(w):
        if flood[0, x] == 255:
            ff_mask = np.zeros((h + 2, w + 2), np.uint8)
            cv2.floodFill(flood, ff_mask, (x, 0), 128)
        if flood[h - 1, x] == 255:
            ff_mask = np.zeros((h + 2, w + 2), np.uint8)
            cv2.floodFill(flood, ff_mask, (x, h - 1), 128)

    for y in range(h):
        if flood[y, 0] == 255:
            ff_mask = np.zeros((h + 2, w + 2), np.uint8)
            cv2.floodFill(flood, ff_mask, (0, y), 128)
        if flood[y, w - 1] == 255:
            ff_mask = np.zeros((h + 2, w + 2), np.uint8)
            cv2.floodFill(flood, ff_mask, (w - 1, y), 128)

    background_mask = (flood == 128).astype(np.uint8) * 255

    # 5. Invert to foreground
    fg_mask = cv2.bitwise_not(background_mask)

    # 6. Fill holes + cleanup
    fg_mask = fill_holes(fg_mask)
    fg_mask = cv2.morphologyEx(fg_mask, cv2.MORPH_CLOSE, kernel)
    fg_mask = cv2.medianBlur(fg_mask, 3)

    return fg_mask

# ---------------------------------------------------------------------------
# Path helpers
# ---------------------------------------------------------------------------
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_IMAGES_DIR = os.path.join(_SCRIPT_DIR, "images")
_GENERATED_DIR = os.path.join(_SCRIPT_DIR, "generated")


def _resolve_input_path(name: str) -> str:
    """Resolve an image name to its full path in the images/ folder."""
    # If it's already a full/relative path that exists, use it
    if os.path.isfile(name):
        return name

    # Try images/<name> directly
    candidate = os.path.join(_IMAGES_DIR, name)
    if os.path.isfile(candidate):
        return candidate

    # Try images/<name>.png, .jpg, .jpeg
    base, ext = os.path.splitext(name)
    if not ext:
        for ext in [".png", ".jpg", ".jpeg"]:
            candidate = os.path.join(_IMAGES_DIR, base + ext)
            if os.path.isfile(candidate):
                return candidate

    raise FileNotFoundError(
        f"Image not found: tried '{name}' and images/{name}[.png|.jpg|.jpeg]"
    )


def _default_output_path(input_path: str) -> str:
    """Generate output path: generated/<name>_embroidery.png"""
    base = os.path.splitext(os.path.basename(input_path))[0]
    os.makedirs(_GENERATED_DIR, exist_ok=True)
    return os.path.join(_GENERATED_DIR, f"{base}_embroidery.png")

def remove_color_spill(image: np.ndarray, alpha: np.ndarray, bg_color: np.ndarray) -> np.ndarray:
    """
    Remove background color spill from foreground boundary pixels.
    Works even when alpha is binary.
    """
    img = image.copy().astype(np.float32)

    # Binary foreground mask
    fg = (alpha > 127).astype(np.uint8) * 255

    # Build a narrow boundary ring around the foreground
    kernel = np.ones((3, 3), np.uint8)
    dilated = cv2.dilate(fg, kernel, iterations=1)
    eroded = cv2.erode(fg, kernel, iterations=1)
    edge_ring = ((dilated > 0) & (eroded == 0))

    # Compare edge pixels to actual background color
    bg = bg_color.astype(np.float32)
    diff = np.linalg.norm(img - bg, axis=2)

    # Spill pixels = boundary pixels still too close to bg color
    spill = edge_ring & (diff < 90)

    if not np.any(spill):
        return image

    # Replace spill pixels using nearby interior foreground color
    clean_source = cv2.medianBlur(image, 5).astype(np.float32)
    img[spill] = clean_source[spill]

    return img.astype(np.uint8)

# ---------------------------------------------------------------------------
# Main pipeline
# ---------------------------------------------------------------------------
def trim_foreground_alpha(alpha: np.ndarray, trim_px: int = 3) -> np.ndarray:
    """
    Remove thin contaminated edge rim from foreground mask.
    For embroidery-style output, a small inward trim is acceptable.
    """
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    trimmed = cv2.erode(alpha, kernel, iterations=trim_px)
    trimmed = cv2.morphologyEx(trimmed, cv2.MORPH_OPEN, kernel)
    return trimmed


def premultiply_rgb_with_alpha(image: np.ndarray, alpha: np.ndarray) -> np.ndarray:
    """
    Multiply RGB by alpha so transparent edge pixels don't keep visible pink RGB.
    """
    img = image.astype(np.float32)
    a = (alpha.astype(np.float32) / 255.0)[:, :, np.newaxis]
    out = img * a
    return np.clip(out, 0, 255).astype(np.uint8)

def process_image(input_path: str, output_path: str | None = None,
                  config: dict | None = None) -> np.ndarray:
    if output_path is None:
        output_path = _default_output_path(input_path)

    cfg = {**DEFAULT_CONFIG, **(config or {})}
    debug = cfg["debug"]
    ddir = cfg["debug_dir"]

    image = cv2.imread(input_path)
    if image is None:
        raise FileNotFoundError(f"Cannot read image: {input_path}")

    # 1. Resize
    image = resize_image(image, cfg["width"])
    original_resized = image.copy()

    # --- Background alpha extraction (shared by both modes) ---
    background_alpha = None
    if cfg["remove_bg"]:
        background_alpha = extract_background_alpha_from_original(
            original_resized,
            lab_tolerance=cfg["bg_lab_tolerance"]
        )

    # === BACKGROUND-ONLY MODE: clean RGBA output, no stylization ===
    if cfg["background_only_mode"]:
        result = original_resized.copy()
        if background_alpha is not None:
            background_alpha = trim_foreground_alpha(background_alpha, trim_px=2)
            result = premultiply_rgb_with_alpha(result, background_alpha)
            result = np.dstack([result, background_alpha])
        if debug:
            _debug_save(result, ddir, "bg_only_output")
        save_output(result, output_path)
        return result

    # === FULL STYLIZATION MODE ===
    if cfg["remove_bg"] and background_alpha is not None:
        fg_bool = background_alpha > 127
        image[~fg_bool] = [255, 255, 255]  # neutral background

    adaptive_min_area = int(0.0008 * image.shape[0] * image.shape[1])

    # 2. Extract outlines
    outline_mask = np.zeros(image.shape[:2], dtype=np.uint8)
    if cfg["enable_outlines"]:
        outline_mask = extract_outline_mask(image, cfg["dark_threshold"])
        outline_mask = normalize_outline(outline_mask, 2)
    if debug:
        _debug_save(outline_mask, ddir, "01_outline_mask")

    # 3. Extract white highlights
    white_mask = np.zeros(image.shape[:2], dtype=np.uint8)
    white_pixels = image.copy()
    if cfg["enable_whites"]:
        white_mask = extract_white_mask(image, cfg["white_threshold"])
        kernel = np.ones((3, 3), np.uint8)
        white_mask = cv2.dilate(white_mask, kernel, iterations=1)
    if debug:
        _debug_save(white_mask, ddir, "02_white_mask")

    # 3b. Extract large light regions
    light_region_mask = np.zeros(image.shape[:2], dtype=np.uint8)
    if cfg["enable_whites"]:
        light_region_mask = extract_light_region_mask(image)
    if debug:
        _debug_save(light_region_mask, ddir, "02b_light_region_mask")

    # 4. Color layer
    color_layer = image.copy()
    if debug:
        _debug_save(color_layer, ddir, "03_color_layer")

    # 5. Bilateral filter
    if cfg["enable_smoothing"]:
        for _ in range(2):
            color_layer = apply_bilateral_filter(
                color_layer, cfg["bilateral_d"],
                cfg["bilateral_sigma_color"], cfg["bilateral_sigma_space"]
            )

    # 5b. Foreground mask for quantization
    fg_mask = background_alpha.copy() if background_alpha is not None else None

    # 6. K-means quantization (foreground only)
    if cfg["enable_quantization"]:
        color_layer = kmeans_quantization(color_layer, cfg["K"], fg_mask=fg_mask)
        color_layer = cv2.medianBlur(color_layer, 3)
    if debug:
        _debug_save(color_layer, ddir, "04_kmeans")

    # 7. Remove small noisy regions (foreground-aware)
    if cfg["enable_cleanup"] and cfg["enable_quantization"]:
        color_layer = remove_small_regions(color_layer, adaptive_min_area, fg_mask=fg_mask)
    if debug:
        _debug_save(color_layer, ddir, "05_region_cleanup")

    # 8. Morphological closing
    if cfg["enable_cleanup"] and cfg["enable_quantization"]:
        color_layer = apply_morphology(color_layer, cfg["morph_kernel_size"])

    # 9. Merge near-duplicates
    if cfg["enable_quantization"]:
        color_layer = merge_similar_colors(color_layer, min_distance=6)

    # 10. Composite
    result = composite_final(color_layer, outline_mask, white_mask, white_pixels)
    if np.any(light_region_mask):
        result[light_region_mask > 0] = [255, 255, 255]
    result[outline_mask > 0] = [0, 0, 0]
    if debug:
        _debug_save(result, ddir, "06_final")

    # 11. Apply background transparency
    if cfg["remove_bg"] and background_alpha is not None:
        background_alpha = trim_foreground_alpha(background_alpha, trim_px=2)
        result = premultiply_rgb_with_alpha(result, background_alpha)
        result = np.dstack([result, background_alpha])
        if debug:
            _debug_save(background_alpha, ddir, "07_alpha_trimmed")
            _debug_save(result, ddir, "08_bg_removed")

    # 12. Save
    save_output(result, output_path)
    return result

# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="Preprocess LLM-generated portraits for embroidery digitizing."
    )
    parser.add_argument("input", help="Image name (looked up in images/ folder) or full path")
    parser.add_argument("-o", "--output", default=None,
                        help="Output path (default: generated/<name>_embroidery.png)")
    parser.add_argument("-K", type=int, default=6, help="Fill colors (default: 6)")
    parser.add_argument("-w", "--width", type=int, default=512, help="Resize width")
    parser.add_argument("--dark-threshold", type=int, default=80,
                        help="Outline extraction threshold (0-255)")
    parser.add_argument("--white-threshold", type=int, default=200,
                        help="White highlight threshold (0-255)")
    parser.add_argument("--no-remove-bg", action="store_true",
                        help="Skip background removal")
    parser.add_argument("--bg-only", action="store_true",
                        help="Background removal only — no stylization")
    parser.add_argument("--debug", action="store_true", help="Save intermediate outputs")
    parser.add_argument("--debug-dir", default="debug_output", help="Debug output dir")

    args = parser.parse_args()

    user_config = {
        "width": args.width,
        "K": args.K,
        "dark_threshold": args.dark_threshold,
        "white_threshold": args.white_threshold,
        "remove_bg": not args.no_remove_bg,
        "background_only_mode": args.bg_only,
        "debug": args.debug,
        "debug_dir": args.debug_dir,
    }

    input_path = _resolve_input_path(args.input)
    out = args.output or _default_output_path(input_path)
    process_image(input_path, out, user_config)
    print(f"Done → {out}")
